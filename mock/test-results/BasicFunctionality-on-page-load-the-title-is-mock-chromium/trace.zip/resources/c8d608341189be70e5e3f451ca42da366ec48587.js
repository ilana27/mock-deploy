export function load(commandArr, setHeader) {
  let filepath = commandArr[1];
  let filepathSplit = filepath.split("/");
  if (!(filepathSplit[0] === "data" || filepathSplit[0] === "." && filepathSplit[1] === "data")) {
    return "Error: filepath " + filepath + " located in an unaccessible directory.";
  }
  if (commandArr.length > 2) {
    let hasHeader = commandArr[2];
    if (hasHeader.toLowerCase() === "true") {
      setHeader(true);
    } else if (hasHeader.toLowerCase() === "false") {
      setHeader(false);
    } else {
      return "Error: header parameter must be either true or false.";
    }
  }
  let validFiles = [
    "data/filepath1",
    "data/filepath2",
    "data/ten-star.csv",
    "data/ten-star_no_headings.csv",
    "data/empty.csv",
    "data/dol_ri_earnings_disparity.csv"
  ];
  if (validFiles.includes(filepath)) {
    return "Load success!";
  }
  return "Error: " + filepath + " not found";
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkxvYWQudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gTm90ZSB0aGlzIGlzIGEgLnRzIGZpbGUsIG5vdCAudHN4LiBJdCdzIFR5cGVTY3JpcHQsIGJ1dCBub3QgUmVhY3QuXG5pbXBvcnQgeyBEaXNwYXRjaCwgU2V0U3RhdGVBY3Rpb24sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5cbi8qKlxuICpcbiAqXG4gKlxuICovXG5leHBvcnQgZnVuY3Rpb24gbG9hZChcbiAgY29tbWFuZEFycjogc3RyaW5nW10sXG4gIHNldEhlYWRlcjogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248Ym9vbGVhbj4+XG4pIHtcbiAgbGV0IGZpbGVwYXRoID0gY29tbWFuZEFyclsxXTtcbiAgbGV0IGZpbGVwYXRoU3BsaXQ6IHN0cmluZ1tdID0gZmlsZXBhdGguc3BsaXQoXCIvXCIpO1xuICBpZiAoXG4gICAgIShcbiAgICAgIGZpbGVwYXRoU3BsaXRbMF0gPT09IFwiZGF0YVwiIHx8XG4gICAgICAoZmlsZXBhdGhTcGxpdFswXSA9PT0gXCIuXCIgJiYgZmlsZXBhdGhTcGxpdFsxXSA9PT0gXCJkYXRhXCIpXG4gICAgKVxuICApIHtcbiAgICByZXR1cm4gKFxuICAgICAgXCJFcnJvcjogZmlsZXBhdGggXCIgKyBmaWxlcGF0aCArIFwiIGxvY2F0ZWQgaW4gYW4gdW5hY2Nlc3NpYmxlIGRpcmVjdG9yeS5cIlxuICAgICk7XG4gIH1cbiAgaWYgKGNvbW1hbmRBcnIubGVuZ3RoID4gMikge1xuICAgIGxldCBoYXNIZWFkZXIgPSBjb21tYW5kQXJyWzJdO1xuICAgIGlmIChoYXNIZWFkZXIudG9Mb3dlckNhc2UoKSA9PT0gXCJ0cnVlXCIpIHtcbiAgICAgIHNldEhlYWRlcih0cnVlKTtcbiAgICB9IGVsc2UgaWYgKGhhc0hlYWRlci50b0xvd2VyQ2FzZSgpID09PSBcImZhbHNlXCIpIHtcbiAgICAgIHNldEhlYWRlcihmYWxzZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBcIkVycm9yOiBoZWFkZXIgcGFyYW1ldGVyIG11c3QgYmUgZWl0aGVyIHRydWUgb3IgZmFsc2UuXCI7XG4gICAgfVxuICB9XG4gIGxldCB2YWxpZEZpbGVzOiBzdHJpbmdbXSA9IFtcbiAgICBcImRhdGEvZmlsZXBhdGgxXCIsXG4gICAgXCJkYXRhL2ZpbGVwYXRoMlwiLFxuICAgIFwiZGF0YS90ZW4tc3Rhci5jc3ZcIixcbiAgICBcImRhdGEvdGVuLXN0YXJfbm9faGVhZGluZ3MuY3N2XCIsXG4gICAgXCJkYXRhL2VtcHR5LmNzdlwiLFxuICAgIFwiZGF0YS9kb2xfcmlfZWFybmluZ3NfZGlzcGFyaXR5LmNzdlwiXG4gIF07XG4gIGlmICh2YWxpZEZpbGVzLmluY2x1ZGVzKGZpbGVwYXRoKSkge1xuICAgIHJldHVybiBcIkxvYWQgc3VjY2VzcyFcIjtcbiAgfVxuICByZXR1cm4gXCJFcnJvcjogXCIgKyBmaWxlcGF0aCArIFwiIG5vdCBmb3VuZFwiO1xufVxuIl0sIm1hcHBpbmdzIjoiQUFRTyxnQkFBUyxLQUNkLFlBQ0EsV0FDQTtBQUNBLE1BQUksV0FBVyxXQUFXLENBQUM7QUFDM0IsTUFBSSxnQkFBMEIsU0FBUyxNQUFNLEdBQUc7QUFDaEQsTUFDRSxFQUNFLGNBQWMsQ0FBQyxNQUFNLFVBQ3BCLGNBQWMsQ0FBQyxNQUFNLE9BQU8sY0FBYyxDQUFDLE1BQU0sU0FFcEQ7QUFDQSxXQUNFLHFCQUFxQixXQUFXO0FBQUEsRUFFcEM7QUFDQSxNQUFJLFdBQVcsU0FBUyxHQUFHO0FBQ3pCLFFBQUksWUFBWSxXQUFXLENBQUM7QUFDNUIsUUFBSSxVQUFVLFlBQVksTUFBTSxRQUFRO0FBQ3RDLGdCQUFVLElBQUk7QUFBQSxJQUNoQixXQUFXLFVBQVUsWUFBWSxNQUFNLFNBQVM7QUFDOUMsZ0JBQVUsS0FBSztBQUFBLElBQ2pCLE9BQU87QUFDTCxhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFDQSxNQUFJLGFBQXVCO0FBQUEsSUFDekI7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDQSxNQUFJLFdBQVcsU0FBUyxRQUFRLEdBQUc7QUFDakMsV0FBTztBQUFBLEVBQ1Q7QUFDQSxTQUFPLFlBQVksV0FBVztBQUNoQzsiLCJuYW1lcyI6W119