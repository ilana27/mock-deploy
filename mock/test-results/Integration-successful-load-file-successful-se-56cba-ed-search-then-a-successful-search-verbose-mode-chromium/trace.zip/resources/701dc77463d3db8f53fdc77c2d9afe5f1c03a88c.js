import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=797e586e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=797e586e"; const useState = __vite__cjsImport4_react["useState"];
import { ControlledInput } from "/src/components/ControlledInput.tsx";
import { load } from "/src/functions/Load.ts";
import { Command } from "/src/components/REPL.tsx";
import { view } from "/src/functions/View.ts";
import { search } from "/src/functions/Search.ts";
export function REPLInput(props) {
  _s();
  const [commandString, setCommandString] = useState("");
  const [count, setCount] = useState(0);
  const [filepath, setFilepath] = useState("");
  const [hasHeader, setHeader] = useState(true);
  const handleKey = (e) => {
    if (e.key === "Enter") {
      if (!commandString) {
        return;
      }
      handleSubmit(commandString);
    }
  };
  function handleSubmit(commandString2) {
    let commandArr = commandString2.split(" ");
    let command = commandArr[0];
    let newCommand;
    if (command === "mode") {
      props.setMode(!props.mode);
      newCommand = new Command(commandString2, [], "Mode success!");
    } else if (command === "load_file") {
      if (commandArr.length >= 4 || commandArr.length <= 1) {
        newCommand = new Command(commandString2, [], "Error: incorrect number of arguments given to load_file command");
      } else {
        let loadMessage = load(commandArr, setHeader);
        newCommand = new Command(commandString2, [], loadMessage);
        setFilepath(commandArr[1]);
      }
    } else if (command === "view") {
      newCommand = view(filepath, commandString2);
    } else if (command === "search") {
      newCommand = search(filepath, hasHeader, commandString2);
    } else {
      newCommand = new Command(commandString2, [], "Error: Please provide a valid command. Valid commands: mode, load_file, view, or search <column><value>");
    }
    setCount(count + 1);
    props.setHistory([...props.history, newCommand]);
    setCommandString("");
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-input", onKeyDown: handleKey, children: [
    /* @__PURE__ */ jsxDEV("fieldset", { children: [
      /* @__PURE__ */ jsxDEV("legend", { children: "Enter a command:" }, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLInput.tsx",
        lineNumber: 66,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ControlledInput, { value: commandString, setValue: setCommandString, ariaLabel: "Command input" }, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLInput.tsx",
        lineNumber: 67,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLInput.tsx",
      lineNumber: 65,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLInput.tsx",
      lineNumber: 69,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: () => handleSubmit(commandString), children: [
      "Submitted ",
      count,
      " times"
    ] }, void 0, true, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLInput.tsx",
      lineNumber: 70,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLInput.tsx",
    lineNumber: 64,
    columnNumber: 10
  }, this);
}
_s(REPLInput, "PeSC00mqy/B3LnONcDmk0sduK0E=");
_c = REPLInput;
var _c;
$RefreshReg$(_c, "REPLInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEVROzs7Ozs7Ozs7Ozs7Ozs7OztBQTVFUixPQUFPO0FBQ1AsU0FBbUNBLGdCQUFnQjtBQUNuRCxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLFlBQVk7QUFDckIsU0FBU0MsY0FBYztBQVNoQixnQkFBU0MsVUFBVUMsT0FBdUI7QUFBQUMsS0FBQTtBQUUvQyxRQUFNLENBQUNDLGVBQWVDLGdCQUFnQixJQUFJVixTQUFpQixFQUFFO0FBQzdELFFBQU0sQ0FBQ1csT0FBT0MsUUFBUSxJQUFJWixTQUFpQixDQUFDO0FBQzVDLFFBQU0sQ0FBQ2EsVUFBVUMsV0FBVyxJQUFJZCxTQUFpQixFQUFFO0FBQ25ELFFBQU0sQ0FBQ2UsV0FBV0MsU0FBUyxJQUFJaEIsU0FBa0IsSUFBSTtBQUVyRCxRQUFNaUIsWUFBWUEsQ0FBQ0MsTUFBVztBQUM1QixRQUFJQSxFQUFFQyxRQUFRLFNBQVM7QUFDckIsVUFBSSxDQUFDVixlQUFlO0FBQ2xCO0FBQUEsTUFDRjtBQUNBVyxtQkFBYVgsYUFBYTtBQUFBLElBQzVCO0FBQUEsRUFDRjtBQUdBLFdBQVNXLGFBQWFYLGdCQUF1QjtBQUMzQyxRQUFJWSxhQUE0QlosZUFBY2EsTUFBTSxHQUFHO0FBQ3ZELFFBQUlDLFVBQWtCRixXQUFXLENBQUM7QUFDbEMsUUFBSUc7QUFDSixRQUFJRCxZQUFZLFFBQVE7QUFDdEJoQixZQUFNa0IsUUFBUSxDQUFDbEIsTUFBTW1CLElBQUk7QUFDekJGLG1CQUFhLElBQUlyQixRQUFRTSxnQkFBZSxJQUFJLGVBQWU7QUFBQSxJQUM3RCxXQUFXYyxZQUFZLGFBQWE7QUFFbEMsVUFBSUYsV0FBV00sVUFBVSxLQUFLTixXQUFXTSxVQUFVLEdBQUc7QUFDcERILHFCQUFhLElBQUlyQixRQUNmTSxnQkFDQSxJQUNBLGlFQUNGO0FBQUEsTUFDRixPQUFPO0FBQ0wsWUFBSW1CLGNBQXNCMUIsS0FBS21CLFlBQVlMLFNBQVM7QUFDcERRLHFCQUFhLElBQUlyQixRQUFRTSxnQkFBZSxJQUFJbUIsV0FBVztBQUN2RGQsb0JBQVlPLFdBQVcsQ0FBQyxDQUFDO0FBQUEsTUFDM0I7QUFBQSxJQUNGLFdBQVdFLFlBQVksUUFBUTtBQUM3QkMsbUJBQWFwQixLQUFLUyxVQUFVSixjQUFhO0FBQUEsSUFDM0MsV0FBV2MsWUFBWSxVQUFVO0FBQy9CQyxtQkFBYW5CLE9BQU9RLFVBQVVFLFdBQVdOLGNBQWE7QUFBQSxJQUN4RCxPQUFPO0FBQ0xlLG1CQUFhLElBQUlyQixRQUNmTSxnQkFDQSxJQUNBLHlHQUNGO0FBQUEsSUFDRjtBQUVBRyxhQUFTRCxRQUFRLENBQUM7QUFFbEJKLFVBQU1zQixXQUFXLENBQUMsR0FBR3RCLE1BQU11QixTQUFTTixVQUFVLENBQUM7QUFDL0NkLHFCQUFpQixFQUFFO0FBQUEsRUFDckI7QUFLQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxjQUFhLFdBQVdPLFdBQ3JDO0FBQUEsMkJBQUMsY0FDQztBQUFBLDZCQUFDLFlBQU8sZ0NBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QjtBQUFBLE1BQ3hCLHVCQUFDLG1CQUNDLE9BQU9SLGVBQ1AsVUFBVUMsa0JBQ1YsV0FBVyxtQkFIYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRzZCO0FBQUEsU0FML0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFDQSx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBRztBQUFBLElBQ0gsdUJBQUMsWUFBTyxTQUFTLE1BQU1VLGFBQWFYLGFBQWEsR0FBRTtBQUFBO0FBQUEsTUFDdENFO0FBQUFBLE1BQU07QUFBQSxTQURuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FhQTtBQUVKO0FBQUNILEdBMUVlRixXQUFTO0FBQUF5QixLQUFUekI7QUFBUyxJQUFBeUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQ29udHJvbGxlZElucHV0IiwibG9hZCIsIkNvbW1hbmQiLCJ2aWV3Iiwic2VhcmNoIiwiUkVQTElucHV0IiwicHJvcHMiLCJfcyIsImNvbW1hbmRTdHJpbmciLCJzZXRDb21tYW5kU3RyaW5nIiwiY291bnQiLCJzZXRDb3VudCIsImZpbGVwYXRoIiwic2V0RmlsZXBhdGgiLCJoYXNIZWFkZXIiLCJzZXRIZWFkZXIiLCJoYW5kbGVLZXkiLCJlIiwia2V5IiwiaGFuZGxlU3VibWl0IiwiY29tbWFuZEFyciIsInNwbGl0IiwiY29tbWFuZCIsIm5ld0NvbW1hbmQiLCJzZXRNb2RlIiwibW9kZSIsImxlbmd0aCIsImxvYWRNZXNzYWdlIiwic2V0SGlzdG9yeSIsImhpc3RvcnkiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJFUExJbnB1dC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCI7XG5pbXBvcnQgeyBEaXNwYXRjaCwgU2V0U3RhdGVBY3Rpb24sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBDb250cm9sbGVkSW5wdXQgfSBmcm9tIFwiLi9Db250cm9sbGVkSW5wdXRcIjtcbmltcG9ydCB7IGxvYWQgfSBmcm9tIFwiLi4vZnVuY3Rpb25zL0xvYWRcIjtcbmltcG9ydCB7IENvbW1hbmQgfSBmcm9tIFwiLi9SRVBMXCI7XG5pbXBvcnQgeyB2aWV3IH0gZnJvbSBcIi4uL2Z1bmN0aW9ucy9WaWV3XCI7XG5pbXBvcnQgeyBzZWFyY2ggfSBmcm9tIFwiLi4vZnVuY3Rpb25zL1NlYXJjaFwiO1xuXG5pbnRlcmZhY2UgUkVQTElucHV0UHJvcHMge1xuICBoaXN0b3J5OiBDb21tYW5kW107XG4gIG1vZGU6IGJvb2xlYW47XG4gIHNldEhpc3Rvcnk6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPENvbW1hbmRbXT4+O1xuICBzZXRNb2RlOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxib29sZWFuPj47XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBSRVBMSW5wdXQocHJvcHM6IFJFUExJbnB1dFByb3BzKSB7XG4gIC8vIE1hbmFnZXMgdGhlIGNvbnRlbnRzIG9mIHRoZSBpbnB1dCBib3hcbiAgY29uc3QgW2NvbW1hbmRTdHJpbmcsIHNldENvbW1hbmRTdHJpbmddID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcbiAgY29uc3QgW2NvdW50LCBzZXRDb3VudF0gPSB1c2VTdGF0ZTxudW1iZXI+KDApO1xuICBjb25zdCBbZmlsZXBhdGgsIHNldEZpbGVwYXRoXSA9IHVzZVN0YXRlPHN0cmluZz4oXCJcIik7XG4gIGNvbnN0IFtoYXNIZWFkZXIsIHNldEhlYWRlcl0gPSB1c2VTdGF0ZTxib29sZWFuPih0cnVlKTtcblxuICBjb25zdCBoYW5kbGVLZXkgPSAoZTogYW55KSA9PiB7XG4gICAgaWYgKGUua2V5ID09PSBcIkVudGVyXCIpIHtcbiAgICAgIGlmICghY29tbWFuZFN0cmluZykge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBoYW5kbGVTdWJtaXQoY29tbWFuZFN0cmluZyk7XG4gICAgfVxuICB9O1xuXG4gIC8vIFRoaXMgZnVuY3Rpb24gaXMgdHJpZ2dlcmVkIHdoZW4gdGhlIGJ1dHRvbiBpcyBjbGlja2VkLlxuICBmdW5jdGlvbiBoYW5kbGVTdWJtaXQoY29tbWFuZFN0cmluZzogc3RyaW5nKSB7XG4gICAgbGV0IGNvbW1hbmRBcnI6IEFycmF5PHN0cmluZz4gPSBjb21tYW5kU3RyaW5nLnNwbGl0KFwiIFwiKTtcbiAgICBsZXQgY29tbWFuZDogU3RyaW5nID0gY29tbWFuZEFyclswXTtcbiAgICBsZXQgbmV3Q29tbWFuZDogQ29tbWFuZDtcbiAgICBpZiAoY29tbWFuZCA9PT0gXCJtb2RlXCIpIHtcbiAgICAgIHByb3BzLnNldE1vZGUoIXByb3BzLm1vZGUpO1xuICAgICAgbmV3Q29tbWFuZCA9IG5ldyBDb21tYW5kKGNvbW1hbmRTdHJpbmcsIFtdLCBcIk1vZGUgc3VjY2VzcyFcIik7XG4gICAgfSBlbHNlIGlmIChjb21tYW5kID09PSBcImxvYWRfZmlsZVwiKSB7XG4gICAgICAvL2xvYWRcbiAgICAgIGlmIChjb21tYW5kQXJyLmxlbmd0aCA+PSA0IHx8IGNvbW1hbmRBcnIubGVuZ3RoIDw9IDEpIHtcbiAgICAgICAgbmV3Q29tbWFuZCA9IG5ldyBDb21tYW5kKFxuICAgICAgICAgIGNvbW1hbmRTdHJpbmcsXG4gICAgICAgICAgW10sXG4gICAgICAgICAgXCJFcnJvcjogaW5jb3JyZWN0IG51bWJlciBvZiBhcmd1bWVudHMgZ2l2ZW4gdG8gbG9hZF9maWxlIGNvbW1hbmRcIlxuICAgICAgICApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbGV0IGxvYWRNZXNzYWdlOiBzdHJpbmcgPSBsb2FkKGNvbW1hbmRBcnIsIHNldEhlYWRlcik7XG4gICAgICAgIG5ld0NvbW1hbmQgPSBuZXcgQ29tbWFuZChjb21tYW5kU3RyaW5nLCBbXSwgbG9hZE1lc3NhZ2UpO1xuICAgICAgICBzZXRGaWxlcGF0aChjb21tYW5kQXJyWzFdKTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGNvbW1hbmQgPT09IFwidmlld1wiKSB7XG4gICAgICBuZXdDb21tYW5kID0gdmlldyhmaWxlcGF0aCwgY29tbWFuZFN0cmluZyk7XG4gICAgfSBlbHNlIGlmIChjb21tYW5kID09PSBcInNlYXJjaFwiKSB7XG4gICAgICBuZXdDb21tYW5kID0gc2VhcmNoKGZpbGVwYXRoLCBoYXNIZWFkZXIsIGNvbW1hbmRTdHJpbmcpO1xuICAgIH0gZWxzZSB7XG4gICAgICBuZXdDb21tYW5kID0gbmV3IENvbW1hbmQoXG4gICAgICAgIGNvbW1hbmRTdHJpbmcsXG4gICAgICAgIFtdLFxuICAgICAgICBcIkVycm9yOiBQbGVhc2UgcHJvdmlkZSBhIHZhbGlkIGNvbW1hbmQuIFZhbGlkIGNvbW1hbmRzOiBtb2RlLCBsb2FkX2ZpbGUsIHZpZXcsIG9yIHNlYXJjaCA8Y29sdW1uPjx2YWx1ZT5cIlxuICAgICAgKTtcbiAgICB9XG5cbiAgICBzZXRDb3VudChjb3VudCArIDEpO1xuICAgIC8vIENIQU5HRURcbiAgICBwcm9wcy5zZXRIaXN0b3J5KFsuLi5wcm9wcy5oaXN0b3J5LCBuZXdDb21tYW5kXSk7XG4gICAgc2V0Q29tbWFuZFN0cmluZyhcIlwiKTtcbiAgfVxuICAvKipcbiAgICogV2Ugc3VnZ2VzdCBicmVha2luZyBkb3duIHRoaXMgY29tcG9uZW50IGludG8gc21hbGxlciBjb21wb25lbnRzLCB0aGluayBhYm91dCB0aGUgaW5kaXZpZHVhbCBwaWVjZXNcbiAgICogb2YgdGhlIFJFUEwgYW5kIGhvdyB0aGV5IGNvbm5lY3QgdG8gZWFjaCBvdGhlci4uLlxuICAgKi9cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJlcGwtaW5wdXRcIiBvbktleURvd249e2hhbmRsZUtleX0+XG4gICAgICA8ZmllbGRzZXQ+XG4gICAgICAgIDxsZWdlbmQ+RW50ZXIgYSBjb21tYW5kOjwvbGVnZW5kPlxuICAgICAgICA8Q29udHJvbGxlZElucHV0XG4gICAgICAgICAgdmFsdWU9e2NvbW1hbmRTdHJpbmd9XG4gICAgICAgICAgc2V0VmFsdWU9e3NldENvbW1hbmRTdHJpbmd9XG4gICAgICAgICAgYXJpYUxhYmVsPXtcIkNvbW1hbmQgaW5wdXRcIn1cbiAgICAgICAgLz5cbiAgICAgIDwvZmllbGRzZXQ+XG4gICAgICA8YnIgLz5cbiAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gaGFuZGxlU3VibWl0KGNvbW1hbmRTdHJpbmcpfT5cbiAgICAgICAgU3VibWl0dGVkIHtjb3VudH0gdGltZXNcbiAgICAgIDwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvaWxhbmEvRGVza3RvcC9Ccm93bi9DUzMyL21vY2staW5ndXllbjQtc3JpZGxleS9tb2NrL3NyYy9jb21wb25lbnRzL1JFUExJbnB1dC50c3gifQ==