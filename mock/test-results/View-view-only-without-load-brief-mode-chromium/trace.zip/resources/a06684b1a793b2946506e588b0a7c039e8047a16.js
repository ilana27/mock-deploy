import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPL.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=797e586e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPL.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=797e586e"; const useState = __vite__cjsImport4_react["useState"];
import { REPLHistory } from "/src/components/REPLHistory.tsx";
import { REPLInput } from "/src/components/REPLInput.tsx";
export default function REPL() {
  _s();
  const [history, setHistory] = useState([]);
  const [mode, setMode] = useState(true);
  return /* @__PURE__ */ jsxDEV("div", { className: "repl", children: [
    /* @__PURE__ */ jsxDEV(REPLHistory, { history, mode }, void 0, false, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPL.tsx",
      lineNumber: 21,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPL.tsx",
      lineNumber: 22,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(REPLInput, { history, mode, setHistory, setMode }, void 0, false, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPL.tsx",
      lineNumber: 23,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPL.tsx",
    lineNumber: 20,
    columnNumber: 10
  }, this);
}
_s(REPL, "EE/+zzCPWE/UN2RrvKW7VIHPOrg=");
_c = REPL;
var _c;
$RefreshReg$(_c, "REPL");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPL.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXBCTixPQUFPO0FBQ1AsU0FBU0EsZ0JBQWdCO0FBQ3pCLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxpQkFBaUI7QUFVMUIsd0JBQXdCQyxPQUFPO0FBQUFDLEtBQUE7QUFFN0IsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUlOLFNBQW9CLEVBQUU7QUFDcEQsUUFBTSxDQUFDTyxNQUFNQyxPQUFPLElBQUlSLFNBQWtCLElBQUk7QUFFOUMsU0FDRSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLDJCQUFDLGVBQVksU0FBa0IsUUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQztBQUFBLElBQzFDLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFJO0FBQUEsSUFDSix1QkFBQyxhQUNDLFNBQ0EsTUFDQSxZQUNBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUltQjtBQUFBLE9BUHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FTQTtBQUVKO0FBQUNJLEdBakJ1QkQsTUFBSTtBQUFBTSxLQUFKTjtBQUFJLElBQUFNO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIlJFUExIaXN0b3J5IiwiUkVQTElucHV0IiwiUkVQTCIsIl9zIiwiaGlzdG9yeSIsInNldEhpc3RvcnkiLCJtb2RlIiwic2V0TW9kZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVQTC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCI7XG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgUkVQTEhpc3RvcnkgfSBmcm9tIFwiLi9SRVBMSGlzdG9yeVwiO1xuaW1wb3J0IHsgUkVQTElucHV0IH0gZnJvbSBcIi4vUkVQTElucHV0XCI7XG5pbXBvcnQgeyBDb21tYW5kIH0gZnJvbSBcIi4uL2Z1bmN0aW9ucy9Db21tYW5kXCI7XG5cbi8qKlxuICogVGhpcyBjb21wb25lbnQgaXMgY2FsbGVkIGFzIHBhcnQgb2YgdGhlIEFwcCBjb21wb25lbnQuXG4gKiBUaGUgY29tcG9uZW50IGVuY2xvc2VzIGJvdGggdGhlIFJFUExIaXN0b3J5IGNvbXBvbmVudCBhbmQgdGhlIFJFUExJbnB1dCBjb21wb25lbnQsXG4gKiB3aGljaCB0b2dldGhlciBkaXNwbGF5cyB0aGUgZnVsbCBzY3JlZW4gb2YgdGhlIGNvbW1hbmQgbG9nIGFuZCB0aGUgY29tbWFuZCBpbnB1dFxuICogYXJlYSBhdCB0aGUgYm90dG9tLlxuICogQHJldHVybnMgQW4gSFRNTCBkaXYgaW5jbHVkaW5nIGJvdGggUkVQTEhpc3RvcnkgYW5kIFJFUExJbnB1dCBjb21wb25lbnRzXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFJFUEwoKSB7XG4gIC8vIFRoZXNlIGNvbnN0YW50cyBtYW5hZ2UgdGhlIHN0YXRlIHRoYXQgc3ViLWNvbXBvbmVudHMgaGF2ZSBhY2Nlc3MgdG9cbiAgY29uc3QgW2hpc3RvcnksIHNldEhpc3RvcnldID0gdXNlU3RhdGU8Q29tbWFuZFtdPihbXSk7XG4gIGNvbnN0IFttb2RlLCBzZXRNb2RlXSA9IHVzZVN0YXRlPGJvb2xlYW4+KHRydWUpO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZXBsXCI+XG4gICAgICA8UkVQTEhpc3RvcnkgaGlzdG9yeT17aGlzdG9yeX0gbW9kZT17bW9kZX0gLz5cbiAgICAgIDxocj48L2hyPlxuICAgICAgPFJFUExJbnB1dFxuICAgICAgICBoaXN0b3J5PXtoaXN0b3J5fVxuICAgICAgICBtb2RlPXttb2RlfVxuICAgICAgICBzZXRIaXN0b3J5PXtzZXRIaXN0b3J5fVxuICAgICAgICBzZXRNb2RlPXtzZXRNb2RlfVxuICAgICAgLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2lsYW5hL0Rlc2t0b3AvQnJvd24vQ1MzMi9tb2NrLWluZ3V5ZW40LXNyaWRsZXkvbW9jay9zcmMvY29tcG9uZW50cy9SRVBMLnRzeCJ9