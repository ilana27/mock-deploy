import { Command } from "/src/functions/Command.ts";
import { validFiles, searchMap } from "/src/functions/mockedJson.ts";
export function search(filepath, hasHeader, commandString) {
  if (!validFiles.includes(filepath)) {
    return new Command(
      commandString,
      [],
      "Error: CSV file could not be searched. Load correct filepath first."
    );
  }
  let commandStringReg = commandString.match(/(?:[^\s"]+|"[^"]*")+/g);
  if (commandStringReg == null) {
    return new Command(
      commandString,
      [],
      "Error: incorrect number of arguments given to search command. Two arguments expected: <column> <value>."
    );
  }
  let commandStringSplit = commandStringReg.map((segment) => {
    return segment.replaceAll('"', "");
  });
  if (commandStringSplit.length !== 3) {
    return new Command(
      commandString,
      [],
      "Error: incorrect number of arguments given to search command. Two arguments expected: <column> <value>."
    );
  }
  let result = searchMap.get(
    filepath + " " + commandStringSplit[1] + " " + commandStringSplit[2] + " " + String(hasHeader)
  );
  if (result === void 0) {
    if (!hasHeader && isNaN(parseInt(commandStringSplit[1]))) {
      return new Command(
        commandString,
        [],
        'Error: search unsuccessful, could not search non-numeric column ID "' + commandStringSplit[1] + '" in file with no headers.'
      );
    }
    return new Command(
      commandString,
      [],
      "Error: search unsuccessful, could not find the value in the given column."
    );
  }
  if (result.length === 0) {
    return new Command(
      commandString,
      result,
      'Search success! However, no rows matching the search criteria "' + commandString + '" were found.'
    );
  }
  return new Command(commandString, result, "Search success!");
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlNlYXJjaC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIFNlYXJjaCBmdW5jdGlvblxuICovXG5pbXBvcnQgeyBDb21tYW5kIH0gZnJvbSBcIi4uL2Z1bmN0aW9ucy9Db21tYW5kXCI7XG5pbXBvcnQgeyB2YWxpZEZpbGVzLCBzZWFyY2hNYXAgfSBmcm9tIFwiLi4vZnVuY3Rpb25zL21vY2tlZEpzb25cIjtcblxuLyoqXG4gKiBTZWFyY2ggZnVuY3Rpb25cbiAqIEBwYXJhbSBmaWxlcGF0aCBzdHJpbmcgY29udGFpbmluZyB0aGUgZmlsZXBhdGhcbiAqIEBwYXJhbSBoYXNIZWFkZXIgYm9vbGVhbiBpbmRpY2F0aW5nIHdoZXRoZXIgdGhlIGdpdmVuIGZpbGUgaGFzIGEgaGVhZGVyIG9yXG4gKiBub3RcbiAqIEBwYXJhbSBjb21tYW5kU3RyaW5nIHN0cmluZyBjb250YWluaW5nIHRoZSB3aG9sZSBjb21tYW5kIGdpdmVuIGJ5IHRoZSB1c2VyXG4gKiBzcGxpdCBpbnRvIGluZGl2aWR1YWwgc3RyaW5ncyBieSBhIHNwYWNlIGRlbGltaXRlclxuICogQHJldHVybnMgYSBDb21tYW5kIHdpdGggdGhlIGNvbW1hbmQgc3RyaW5nLCB0aGUgcmVzdWx0IG9mIHNlYXJjaGluZywgYW5kIGFcbiAqIG1lc3NhZ2UgaW5kaWNhdGluZyBzZWFyY2ggc3VjY2VzcyBvciBhbiBlcnJvci5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNlYXJjaChcbiAgZmlsZXBhdGg6IHN0cmluZyxcbiAgaGFzSGVhZGVyOiBib29sZWFuLFxuICBjb21tYW5kU3RyaW5nOiBzdHJpbmdcbikge1xuICBpZiAoIXZhbGlkRmlsZXMuaW5jbHVkZXMoZmlsZXBhdGgpKSB7XG4gICAgcmV0dXJuIG5ldyBDb21tYW5kKFxuICAgICAgY29tbWFuZFN0cmluZyxcbiAgICAgIFtdLFxuICAgICAgXCJFcnJvcjogQ1NWIGZpbGUgY291bGQgbm90IGJlIHNlYXJjaGVkLiBMb2FkIGNvcnJlY3QgZmlsZXBhdGggZmlyc3QuXCJcbiAgICApO1xuICB9XG4gIC8vIFVzZSBhIHJlZ2V4IHRvIHNwbGl0IHRoZSBjb21tYW5kU3RyaW5nXG4gIGxldCBjb21tYW5kU3RyaW5nUmVnOiBSZWdFeHBNYXRjaEFycmF5IHwgbnVsbCA9XG4gICAgY29tbWFuZFN0cmluZy5tYXRjaCgvKD86W15cXHNcIl0rfFwiW15cIl0qXCIpKy9nKTtcbiAgaWYgKGNvbW1hbmRTdHJpbmdSZWcgPT0gbnVsbCkge1xuICAgIHJldHVybiBuZXcgQ29tbWFuZChcbiAgICAgIGNvbW1hbmRTdHJpbmcsXG4gICAgICBbXSxcbiAgICAgIFwiRXJyb3I6IGluY29ycmVjdCBudW1iZXIgb2YgYXJndW1lbnRzIGdpdmVuIHRvIHNlYXJjaCBjb21tYW5kLiBUd28gYXJndW1lbnRzIGV4cGVjdGVkOiA8Y29sdW1uPiA8dmFsdWU+LlwiXG4gICAgKTtcbiAgfVxuICAvLyBSZW1vdmUgdGhlIHF1b3RhdGlvbiBtYXJrcyBmcm9tIHRoZSBzcGxpdCBzdHJpbmdzXG4gIGxldCBjb21tYW5kU3RyaW5nU3BsaXQgPSBjb21tYW5kU3RyaW5nUmVnLm1hcCgoc2VnbWVudCkgPT4ge1xuICAgIHJldHVybiBzZWdtZW50LnJlcGxhY2VBbGwoJ1wiJywgXCJcIik7XG4gIH0pO1xuICBpZiAoY29tbWFuZFN0cmluZ1NwbGl0Lmxlbmd0aCAhPT0gMykge1xuICAgIHJldHVybiBuZXcgQ29tbWFuZChcbiAgICAgIGNvbW1hbmRTdHJpbmcsXG4gICAgICBbXSxcbiAgICAgIFwiRXJyb3I6IGluY29ycmVjdCBudW1iZXIgb2YgYXJndW1lbnRzIGdpdmVuIHRvIHNlYXJjaCBjb21tYW5kLiBUd28gYXJndW1lbnRzIGV4cGVjdGVkOiA8Y29sdW1uPiA8dmFsdWU+LlwiXG4gICAgKTtcbiAgfVxuICAvLyBBdHRlbXB0IHRvIGZpbmQgdGhlIHNlYXJjaGVkIGRhdGEgaW4gdGhlIGxvYWRlZCBDU1YgZGF0YVxuICBsZXQgcmVzdWx0ID0gc2VhcmNoTWFwLmdldChcbiAgICBmaWxlcGF0aCArXG4gICAgICBcIiBcIiArXG4gICAgICBjb21tYW5kU3RyaW5nU3BsaXRbMV0gK1xuICAgICAgXCIgXCIgK1xuICAgICAgY29tbWFuZFN0cmluZ1NwbGl0WzJdICtcbiAgICAgIFwiIFwiICtcbiAgICAgIFN0cmluZyhoYXNIZWFkZXIpXG4gICk7XG4gIGlmIChyZXN1bHQgPT09IHVuZGVmaW5lZCkge1xuICAgIGlmICghaGFzSGVhZGVyICYmIGlzTmFOKHBhcnNlSW50KGNvbW1hbmRTdHJpbmdTcGxpdFsxXSkpKSB7XG4gICAgICByZXR1cm4gbmV3IENvbW1hbmQoXG4gICAgICAgIGNvbW1hbmRTdHJpbmcsXG4gICAgICAgIFtdLFxuICAgICAgICAnRXJyb3I6IHNlYXJjaCB1bnN1Y2Nlc3NmdWwsIGNvdWxkIG5vdCBzZWFyY2ggbm9uLW51bWVyaWMgY29sdW1uIElEIFwiJyArXG4gICAgICAgICAgY29tbWFuZFN0cmluZ1NwbGl0WzFdICtcbiAgICAgICAgICAnXCIgaW4gZmlsZSB3aXRoIG5vIGhlYWRlcnMuJ1xuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuIG5ldyBDb21tYW5kKFxuICAgICAgY29tbWFuZFN0cmluZyxcbiAgICAgIFtdLFxuICAgICAgXCJFcnJvcjogc2VhcmNoIHVuc3VjY2Vzc2Z1bCwgY291bGQgbm90IGZpbmQgdGhlIHZhbHVlIGluIHRoZSBnaXZlbiBjb2x1bW4uXCJcbiAgICApO1xuICB9XG4gIGlmIChyZXN1bHQubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIG5ldyBDb21tYW5kKFxuICAgICAgY29tbWFuZFN0cmluZyxcbiAgICAgIHJlc3VsdCxcbiAgICAgICdTZWFyY2ggc3VjY2VzcyEgSG93ZXZlciwgbm8gcm93cyBtYXRjaGluZyB0aGUgc2VhcmNoIGNyaXRlcmlhIFwiJyArXG4gICAgICAgIGNvbW1hbmRTdHJpbmcgK1xuICAgICAgICAnXCIgd2VyZSBmb3VuZC4nXG4gICAgKTtcbiAgfVxuICByZXR1cm4gbmV3IENvbW1hbmQoY29tbWFuZFN0cmluZywgcmVzdWx0LCBcIlNlYXJjaCBzdWNjZXNzIVwiKTtcbn1cbiJdLCJtYXBwaW5ncyI6IkFBR0EsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsWUFBWSxpQkFBaUI7QUFZL0IsZ0JBQVMsT0FDZCxVQUNBLFdBQ0EsZUFDQTtBQUNBLE1BQUksQ0FBQyxXQUFXLFNBQVMsUUFBUSxHQUFHO0FBQ2xDLFdBQU8sSUFBSTtBQUFBLE1BQ1Q7QUFBQSxNQUNBLENBQUM7QUFBQSxNQUNEO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxNQUFJLG1CQUNGLGNBQWMsTUFBTSx1QkFBdUI7QUFDN0MsTUFBSSxvQkFBb0IsTUFBTTtBQUM1QixXQUFPLElBQUk7QUFBQSxNQUNUO0FBQUEsTUFDQSxDQUFDO0FBQUEsTUFDRDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsTUFBSSxxQkFBcUIsaUJBQWlCLElBQUksQ0FBQyxZQUFZO0FBQ3pELFdBQU8sUUFBUSxXQUFXLEtBQUssRUFBRTtBQUFBLEVBQ25DLENBQUM7QUFDRCxNQUFJLG1CQUFtQixXQUFXLEdBQUc7QUFDbkMsV0FBTyxJQUFJO0FBQUEsTUFDVDtBQUFBLE1BQ0EsQ0FBQztBQUFBLE1BQ0Q7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLE1BQUksU0FBUyxVQUFVO0FBQUEsSUFDckIsV0FDRSxNQUNBLG1CQUFtQixDQUFDLElBQ3BCLE1BQ0EsbUJBQW1CLENBQUMsSUFDcEIsTUFDQSxPQUFPLFNBQVM7QUFBQSxFQUNwQjtBQUNBLE1BQUksV0FBVyxRQUFXO0FBQ3hCLFFBQUksQ0FBQyxhQUFhLE1BQU0sU0FBUyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsR0FBRztBQUN4RCxhQUFPLElBQUk7QUFBQSxRQUNUO0FBQUEsUUFDQSxDQUFDO0FBQUEsUUFDRCx5RUFDRSxtQkFBbUIsQ0FBQyxJQUNwQjtBQUFBLE1BQ0o7QUFBQSxJQUNGO0FBQ0EsV0FBTyxJQUFJO0FBQUEsTUFDVDtBQUFBLE1BQ0EsQ0FBQztBQUFBLE1BQ0Q7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLE1BQUksT0FBTyxXQUFXLEdBQUc7QUFDdkIsV0FBTyxJQUFJO0FBQUEsTUFDVDtBQUFBLE1BQ0E7QUFBQSxNQUNBLG9FQUNFLGdCQUNBO0FBQUEsSUFDSjtBQUFBLEVBQ0Y7QUFDQSxTQUFPLElBQUksUUFBUSxlQUFlLFFBQVEsaUJBQWlCO0FBQzdEOyIsIm5hbWVzIjpbXX0=