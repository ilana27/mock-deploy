import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CsvTable.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=797e586e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/CsvTable.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export default function CsvTable(props) {
  const rows = props.data.map((row, index) => {
    return /* @__PURE__ */ jsxDEV("tr", { children: row.map((column, index2) => {
      return /* @__PURE__ */ jsxDEV("td", { children: column }, `cell-${index2}`, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/CsvTable.tsx",
        lineNumber: 21,
        columnNumber: 16
      }, this);
    }) }, `row-${index}`, false, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/CsvTable.tsx",
      lineNumber: 19,
      columnNumber: 12
    }, this);
  });
  return /* @__PURE__ */ jsxDEV("table", { children: /* @__PURE__ */ jsxDEV("tbody", { children: rows }, void 0, false, {
    fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/CsvTable.tsx",
    lineNumber: 26,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/CsvTable.tsx",
    lineNumber: 25,
    columnNumber: 10
  }, this);
}
_c = CsvTable;
var _c;
$RefreshReg$(_c, "CsvTable");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/CsvTable.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJpQjtBQXJCakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBZ0JBLHdCQUF3QkEsU0FBU0MsT0FBc0I7QUFDckQsUUFBTUMsT0FBT0QsTUFBTUUsS0FBS0MsSUFBSSxDQUFDQyxLQUFlQyxVQUFrQjtBQUM1RCxXQUNFLHVCQUFDLFFBQ0VELGNBQUlELElBQUksQ0FBQ0csUUFBZ0JDLFdBQW1CO0FBQzNDLGFBQU8sdUJBQUMsUUFBMkJELG9CQUFsQixRQUFPQyxNQUFPLElBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUM7QUFBQSxJQUM1QyxDQUFDLEtBSE8sT0FBTUYsS0FBTSxJQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxFQUVKLENBQUM7QUFFRCxTQUNFLHVCQUFDLFdBQ0MsaUNBQUMsV0FBT0osa0JBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFhLEtBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBRUo7QUFBQ08sS0FoQnVCVDtBQUFRLElBQUFTO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJDc3ZUYWJsZSIsInByb3BzIiwicm93cyIsImRhdGEiLCJtYXAiLCJyb3ciLCJpbmRleCIsImNvbHVtbiIsImluZGV4MiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ3N2VGFibGUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogVGhlc2UgYXJlIHRoZSBwcm9wcyBmb3IgdGhlIENzdlRhYmxlIGNvbXBvbmVudC5cbiAqIC0gZGF0YSBpcyBhIGxpc3Qgb2YgbGlzdCBvZiBzdHJpbmcsIHJlcHJlc2VudGluZyB0aGUgcm93cyBvZiBkYXRhIHJldHVybmVkIGJ5IGEgdmlld1xuICogb3Igc2VhcmNoIGNvbW1hbmQsIG9yIGFuIGVtcHR5IHRhYmxlIGZvciBhIGNvbW1hbmQgdGhhdCBkb2VzIG5vdCByZXR1cm4gZGF0YSAoYSBtb2RlLFxuICogbG9hZF9maWxlLCBvciB1bnJlY29nbml6ZWQgY29tbWFuZClcbiAqL1xuaW50ZXJmYWNlIENzdlRhYmxlUHJvcHMge1xuICBkYXRhOiBzdHJpbmdbXVtdO1xufVxuXG4vKipcbiAqIFRoaXMgY29tcG9uZW50IGlzIGNhbGxlZCBhcyBwYXJ0IG9mIHRoZSBSRVBsSGlzdG9yeSBjb21tYW5kLCBmb3IgZXZlcnkgdGFibGUgdGhhdFxuICogbmVlZHMgdG8gYmUgZGlzcGxheWVkIGluIHRoZSBjb21tYW5kIGhpc3RvcnkgYXJlYS5cbiAqIEBwYXJhbSBwcm9wcyBpcyB0aGUgaW50ZXJmYWNlIGFib3ZlIGNvbnRhaW5pbmcgdGhlIGFyZ3VtZW50cyB0byBDc3ZUYWJsZVxuICogQHJldHVybnMgYW4gSFRNTCB0YWJsZSBjb250YWluaW5nIHRoZSBDU1YgZGF0YSBvdXRwdXQgYnkgYSBjb21tYW5kXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENzdlRhYmxlKHByb3BzOiBDc3ZUYWJsZVByb3BzKSB7XG4gIGNvbnN0IHJvd3MgPSBwcm9wcy5kYXRhLm1hcCgocm93OiBzdHJpbmdbXSwgaW5kZXg6IG51bWJlcikgPT4ge1xuICAgIHJldHVybiAoXG4gICAgICA8dHIga2V5PXtgcm93LSR7aW5kZXh9YH0+XG4gICAgICAgIHtyb3cubWFwKChjb2x1bW46IHN0cmluZywgaW5kZXgyOiBudW1iZXIpID0+IHtcbiAgICAgICAgICByZXR1cm4gPHRkIGtleT17YGNlbGwtJHtpbmRleDJ9YH0+e2NvbHVtbn08L3RkPjtcbiAgICAgICAgfSl9XG4gICAgICA8L3RyPlxuICAgICk7XG4gIH0pO1xuXG4gIHJldHVybiAoXG4gICAgPHRhYmxlPlxuICAgICAgPHRib2R5Pntyb3dzfTwvdGJvZHk+XG4gICAgPC90YWJsZT5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2lsYW5hL0Rlc2t0b3AvQnJvd24vQ1MzMi9tb2NrLWluZ3V5ZW40LXNyaWRsZXkvbW9jay9zcmMvY29tcG9uZW50cy9Dc3ZUYWJsZS50c3gifQ==