import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ControlledInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=797e586e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/ControlledInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
export function ControlledInput(props) {
  return /* @__PURE__ */ jsxDEV("input", { type: "text", className: "repl-command-box", value: props.value, placeholder: "Enter command here!", onChange: (ev) => props.setValue(ev.target.value), "aria-label": props.ariaLabel }, void 0, false, {
    fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/ControlledInput.tsx",
    lineNumber: 23,
    columnNumber: 10
  }, this);
}
_c = ControlledInput;
var _c;
$RefreshReg$(_c, "ControlledInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/ControlledInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUJJO0FBdkJKLE9BQU8sb0JBQW9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBcUJwQixnQkFBU0EsZ0JBQWdCQyxPQUE2QjtBQUMzRCxTQUNFLHVCQUFDLFdBQ0MsTUFBSyxRQUNMLFdBQVUsb0JBQ1YsT0FBT0EsTUFBTUMsT0FDYixhQUFZLHVCQUNaLFVBQVdDLFFBQU9GLE1BQU1HLFNBQVNELEdBQUdFLE9BQU9ILEtBQUssR0FDaEQsY0FBWUQsTUFBTUssYUFOcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU9DO0FBRUw7QUFBQ0MsS0FYZVA7QUFBZSxJQUFBTztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQ29udHJvbGxlZElucHV0IiwicHJvcHMiLCJ2YWx1ZSIsImV2Iiwic2V0VmFsdWUiLCJ0YXJnZXQiLCJhcmlhTGFiZWwiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNvbnRyb2xsZWRJbnB1dC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCI7XG5pbXBvcnQgeyBEaXNwYXRjaCwgU2V0U3RhdGVBY3Rpb24gfSBmcm9tIFwicmVhY3RcIjtcblxuLyoqXG4gKiBUaGVzZSBhcmUgdGhlIHByb3BzIGZvciB0aGUgQ29udHJvbGxlZElucHV0IGNvbXBvbmVudC5cbiAqIC0gdmFsdWUgaXMgdGhlIHZhbHVlIHRoYXQgaXMgZW50ZXJlZCBpbnRvIHRoZSBjb21tYW5kIGJveFxuICogLSBzZXRWYWx1ZSBpcyBhIGZ1bmN0aW9uIHRoYXQgYWxsb3dzIHRoZSBjYWxsZXIgdG8gdXBkYXRlIHZhbHVlXG4gKiAtIGFyaWFMYWJlbCBpcyB0aGUgbGFiZWwgZm9yIHRoZSBpbnB1dCB0aGF0IGFsbG93cyBwbGF5d3JpZ2h0IHRlc3RpbmdcbiAqL1xuaW50ZXJmYWNlIENvbnRyb2xsZWRJbnB1dFByb3BzIHtcbiAgdmFsdWU6IHN0cmluZztcbiAgc2V0VmFsdWU6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPHN0cmluZz4+O1xuICBhcmlhTGFiZWw6IHN0cmluZztcbn1cblxuLyoqXG4gKiBUaGlzIGNvbXBvbmVudCBhbGxvd3MgdGhlIHVzZXIgdG8gdHlwZSB0aGVpciBpbnB1dCBpbnRvIHRoZSBjb21tYW5kIGJveCwgYW5kXG4gKiB1cGRhdGVzIHRoZSB2YXJpYWJsZSB2YWx1ZSBhcyB0aGUgdXNlciB0eXBlcy5cbiAqIEBwYXJhbSBwcm9wcyBpcyB0aGUgaW50ZXJmYWNlIGFib3ZlIGNvbnRhaW5pbmcgdGhlIGFyZ3VtZW50cyB0byBDb250cm9sbGVkSW5wdXRcbiAqIEByZXR1cm5zIGFuIEhUTUwgaW5wdXQgdGhhdCBzaG93cyBhbmQgdXBkYXRlcyB0aGUgdGV4dCB0aGF0IHRoZSB1c2VyIGhhcyBlbnRlcmVkXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBDb250cm9sbGVkSW5wdXQocHJvcHM6IENvbnRyb2xsZWRJbnB1dFByb3BzKSB7XG4gIHJldHVybiAoXG4gICAgPGlucHV0XG4gICAgICB0eXBlPVwidGV4dFwiXG4gICAgICBjbGFzc05hbWU9XCJyZXBsLWNvbW1hbmQtYm94XCJcbiAgICAgIHZhbHVlPXtwcm9wcy52YWx1ZX1cbiAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgY29tbWFuZCBoZXJlIVwiXG4gICAgICBvbkNoYW5nZT17KGV2KSA9PiBwcm9wcy5zZXRWYWx1ZShldi50YXJnZXQudmFsdWUpfVxuICAgICAgYXJpYS1sYWJlbD17cHJvcHMuYXJpYUxhYmVsfVxuICAgID48L2lucHV0PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvaWxhbmEvRGVza3RvcC9Ccm93bi9DUzMyL21vY2staW5ndXllbjQtc3JpZGxleS9tb2NrL3NyYy9jb21wb25lbnRzL0NvbnRyb2xsZWRJbnB1dC50c3gifQ==