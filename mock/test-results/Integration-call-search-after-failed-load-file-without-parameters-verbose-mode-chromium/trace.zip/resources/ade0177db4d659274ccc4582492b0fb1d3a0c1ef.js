import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CsvTable.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=797e586e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/CsvTable.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
export default function CsvTable(props) {
  const rows = props.data.map((row, index) => {
    return /* @__PURE__ */ jsxDEV("tr", { children: row.map((column, index2) => {
      return /* @__PURE__ */ jsxDEV("td", { children: column }, `cell-${index2}`, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/CsvTable.tsx",
        lineNumber: 9,
        columnNumber: 16
      }, this);
    }) }, `row-${index}`, false, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/CsvTable.tsx",
      lineNumber: 7,
      columnNumber: 12
    }, this);
  });
  return /* @__PURE__ */ jsxDEV("table", { children: /* @__PURE__ */ jsxDEV("tbody", { children: rows }, void 0, false, {
    fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/CsvTable.tsx",
    lineNumber: 14,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/CsvTable.tsx",
    lineNumber: 13,
    columnNumber: 10
  }, this);
}
_c = CsvTable;
var _c;
$RefreshReg$(_c, "CsvTable");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/CsvTable.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVWlCO0FBVmpCLDJCQUF3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFLeEIsd0JBQXdCQSxTQUFTQyxPQUFzQjtBQUNyRCxRQUFNQyxPQUFPRCxNQUFNRSxLQUFLQyxJQUFJLENBQUNDLEtBQWVDLFVBQWtCO0FBQzVELFdBQ0UsdUJBQUMsUUFDRUQsY0FBSUQsSUFBSSxDQUFDRyxRQUFnQkMsV0FBbUI7QUFDM0MsYUFBTyx1QkFBQyxRQUEyQkQsb0JBQWxCLFFBQU9DLE1BQU8sSUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtQztBQUFBLElBQzVDLENBQUMsS0FITyxPQUFNRixLQUFNLElBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLEVBRUosQ0FBQztBQUVELFNBQ0UsdUJBQUMsV0FDQyxpQ0FBQyxXQUFPSixrQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWEsS0FEZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFFSjtBQUFDTyxLQWhCdUJUO0FBQVEsSUFBQVM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkNzdlRhYmxlIiwicHJvcHMiLCJyb3dzIiwiZGF0YSIsIm1hcCIsInJvdyIsImluZGV4IiwiY29sdW1uIiwiaW5kZXgyIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDc3ZUYWJsZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW50ZXJmYWNlIENzdlRhYmxlUHJvcHMge1xuICAvLyBUT0RPOiBGaWxsIHdpdGggc29tZSBzaGFyZWQgc3RhdGUgdHJhY2tpbmcgYWxsIHRoZSBwdXNoZWQgY29tbWFuZHNcbiAgZGF0YTogc3RyaW5nW11bXTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQ3N2VGFibGUocHJvcHM6IENzdlRhYmxlUHJvcHMpIHtcbiAgY29uc3Qgcm93cyA9IHByb3BzLmRhdGEubWFwKChyb3c6IHN0cmluZ1tdLCBpbmRleDogbnVtYmVyKSA9PiB7XG4gICAgcmV0dXJuIChcbiAgICAgIDx0ciBrZXk9e2Byb3ctJHtpbmRleH1gfT5cbiAgICAgICAge3Jvdy5tYXAoKGNvbHVtbjogc3RyaW5nLCBpbmRleDI6IG51bWJlcikgPT4ge1xuICAgICAgICAgIHJldHVybiA8dGQga2V5PXtgY2VsbC0ke2luZGV4Mn1gfT57Y29sdW1ufTwvdGQ+O1xuICAgICAgICB9KX1cbiAgICAgIDwvdHI+XG4gICAgKTtcbiAgfSk7XG5cbiAgcmV0dXJuIChcbiAgICA8dGFibGU+XG4gICAgICA8dGJvZHk+e3Jvd3N9PC90Ym9keT5cbiAgICA8L3RhYmxlPlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvaWxhbmEvRGVza3RvcC9Ccm93bi9DUzMyL21vY2staW5ndXllbjQtc3JpZGxleS9tb2NrL3NyYy9jb21wb25lbnRzL0NzdlRhYmxlLnRzeCJ9