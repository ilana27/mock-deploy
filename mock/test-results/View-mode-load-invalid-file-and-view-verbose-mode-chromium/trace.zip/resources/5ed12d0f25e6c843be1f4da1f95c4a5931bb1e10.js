import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLHistory.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=797e586e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css";
import CsvTable from "/src/components/CsvTable.tsx";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=797e586e"; const useRef = __vite__cjsImport5_react["useRef"]; const useEffect = __vite__cjsImport5_react["useEffect"];
export function REPLHistory(props) {
  _s();
  const messagesEndRef = useRef(null);
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({
      behavior: "smooth"
    });
  };
  useEffect(() => {
    scrollToBottom();
  }, [props.history]);
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-history", children: [
    props.history.map((command, index) => props.mode ? /* @__PURE__ */ jsxDEV("div", { className: "leftAlign", children: [
      /* @__PURE__ */ jsxDEV("p", { "aria-label": "commandMessage" + String(index), children: command.message }, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
        lineNumber: 46,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(CsvTable, { data: command.data }, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
        lineNumber: 49,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
        lineNumber: 50,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
        lineNumber: 51,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
      lineNumber: 45,
      columnNumber: 59
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "leftAlign", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "boldText", children: "Command: " }, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
        lineNumber: 53,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("span", { "aria-label": "commandString" + String(index), children: command.commandString }, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
        lineNumber: 54,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
        lineNumber: 57,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "boldText", children: "Ouptut: " }, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
        lineNumber: 58,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("span", { "aria-label": "commandMessage" + String(index), children: command.message }, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
        lineNumber: 59,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("span", { "aria-label": "data" + String(index), children: /* @__PURE__ */ jsxDEV(CsvTable, { data: command.data }, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
        lineNumber: 63,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
        lineNumber: 62,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
        lineNumber: 65,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
        lineNumber: 66,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
      lineNumber: 52,
      columnNumber: 20
    }, this)),
    /* @__PURE__ */ jsxDEV("div", { ref: messagesEndRef }, void 0, false, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
      lineNumber: 68,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
    lineNumber: 44,
    columnNumber: 10
  }, this);
}
_s(REPLHistory, "0epSoi03NVSoD0I0FiLK4iVNXOA=");
_c = REPLHistory;
var _c;
$RefreshReg$(_c, "REPLHistory");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNENZOzs7Ozs7Ozs7Ozs7Ozs7OztBQTVDWixPQUFPO0FBQ1AsT0FBT0EsY0FBYztBQUVyQixTQUFTQyxRQUFRQyxpQkFBaUI7QUFzQjNCLGdCQUFTQyxZQUFZQyxPQUF5QjtBQUFBQyxLQUFBO0FBRW5ELFFBQU1DLGlCQUFpQkwsT0FBOEIsSUFBSTtBQUN6RCxRQUFNTSxpQkFBaUJBLE1BQU07QUFDM0JELG1CQUFlRSxTQUFTQyxlQUFlO0FBQUEsTUFBRUMsVUFBVTtBQUFBLElBQVMsQ0FBQztBQUFBLEVBQy9EO0FBQ0FSLFlBQVUsTUFBTTtBQUNkSyxtQkFBZTtBQUFBLEVBQ2pCLEdBQUcsQ0FBQ0gsTUFBTU8sT0FBTyxDQUFDO0FBTWxCLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGdCQUNaUDtBQUFBQSxVQUFNTyxRQUFRQyxJQUFJLENBQUNDLFNBQVNDLFVBQzNCVixNQUFNVyxPQUNKLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsNkJBQUMsT0FBRSxjQUFZLG1CQUFtQkMsT0FBT0YsS0FBSyxHQUMzQ0Qsa0JBQVFJLFdBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxZQUFTLE1BQU1KLFFBQVFLLFFBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkI7QUFBQSxNQUM3Qix1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBRztBQUFBLE1BQ0gsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUc7QUFBQSxTQU5MO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsNkJBQUMsVUFBSyxXQUFVLFlBQVcseUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0M7QUFBQSxNQUNwQyx1QkFBQyxVQUFLLGNBQVksa0JBQWtCRixPQUFPRixLQUFLLEdBQzdDRCxrQkFBUU0saUJBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBRztBQUFBLE1BQ0gsdUJBQUMsVUFBSyxXQUFVLFlBQVcsd0JBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUM7QUFBQSxNQUNuQyx1QkFBQyxVQUFLLGNBQVksbUJBQW1CSCxPQUFPRixLQUFLLEdBQzlDRCxrQkFBUUksV0FEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFVBQUssY0FBWSxTQUFTRCxPQUFPRixLQUFLLEdBQ3JDLGlDQUFDLFlBQVMsTUFBTUQsUUFBUUssUUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2QixLQUQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFHO0FBQUEsTUFDSCx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBRztBQUFBLFNBZEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWVBLENBRUo7QUFBQSxJQUNBLHVCQUFDLFNBQUksS0FBS1osa0JBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QjtBQUFBLE9BOUIzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK0JBO0FBRUo7QUFBQ0QsR0FoRGVGLGFBQVc7QUFBQWlCLEtBQVhqQjtBQUFXLElBQUFpQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQ3N2VGFibGUiLCJ1c2VSZWYiLCJ1c2VFZmZlY3QiLCJSRVBMSGlzdG9yeSIsInByb3BzIiwiX3MiLCJtZXNzYWdlc0VuZFJlZiIsInNjcm9sbFRvQm90dG9tIiwiY3VycmVudCIsInNjcm9sbEludG9WaWV3IiwiYmVoYXZpb3IiLCJoaXN0b3J5IiwibWFwIiwiY29tbWFuZCIsImluZGV4IiwibW9kZSIsIlN0cmluZyIsIm1lc3NhZ2UiLCJkYXRhIiwiY29tbWFuZFN0cmluZyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVQTEhpc3RvcnkudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIi4uL3N0eWxlcy9tYWluLmNzc1wiO1xuaW1wb3J0IENzdlRhYmxlIGZyb20gXCIuL0NzdlRhYmxlXCI7XG5pbXBvcnQgeyBDb21tYW5kIH0gZnJvbSBcIi4uL2Z1bmN0aW9ucy9Db21tYW5kXCI7XG5pbXBvcnQgeyB1c2VSZWYsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xuXG4vKipcbiAqIFRoZXNlIGFyZSB0aGUgcHJvcHMgZm9yIHRoZSBSRVBMSGlzdG9yeSBjb21wb25lbnQuXG4gKiAtIGhpc3RvcnkgaXMgYSBsaXN0IG9mIGFsbCBjb21tYW5kcyB0aGF0IGhhdmUgYmVlbiBwdXNoZWQgYnkgdGhlIHVzZXIgaW4gdGhpcyBzZXNzaW9uXG4gKiAtIG1vZGUgaXMgYSBib29sZWFuIHNldCB0byB0cnVlIGlmIGluIGJyaWVmIG1vZGUgKGRlZmF1bHQpLCBhbmQgZmFsc2UgaW4gdmVyYm9zZSBtb2RlXG4gKi9cbmludGVyZmFjZSBSRVBMSGlzdG9yeVByb3BzIHtcbiAgaGlzdG9yeTogQ29tbWFuZFtdO1xuICBtb2RlOiBib29sZWFuO1xufVxuXG4vKipcbiAqIFRoaXMgY29tcG9uZW50IGlzIGNhbGxlZCBhcyBwYXJ0IG9mIHRoZSBSRVBMIGNvbXBvbmVudC5cbiAqIFRoZSBSRVBMSGlzdG9yeSBjb21wb25lbnQgZGlzcGxheXMgZWFjaCBvZiB0aGUgb3V0cHV0cyBvZiBhbGwgb2YgdGhlIGNvbW1hbmRzIHNlbnQgYnlcbiAqIHRoZSB1c2VyIGluIHRoaXMgc2Vzc2lvbi4gSWYgdGhlIGFwcCBpcyBpbiB2ZXJib3NlIG1vZGUsIHRoZSBjb21tYW5kcyB0aGVtc2VsdmVzIGFyZVxuICogYWxzbyBkaXNwbGF5ZWQgaW4gdGhlIFJFUExIaXN0b3J5IGFyZWEuXG4gKiBUaGUgY29tbWFuZHMgYXJlIHN0YWNrZWQgb24gdG9wIG9mIG9uZSBhbm90aGVyLCB3aXRoIHRoZSBvbGRlc2V0IGNvbW1hbmRzIGF0IHRoZSB0b3AuIFRoZVxuICogY29tcG9uZW50IGFsc28gYXV0by1zY3JvbGxzLCBzbyB0aGF0IHRoZSBuZXdlc3QgY29tbWFuZHMgYXJlIHZpc2libGUuXG4gKiBAcGFyYW0gcHJvcHMgaXMgdGhlIGludGVyZmFjZSBhYm92ZSBjb250YWluaW5nIHRoZSBhcmd1bWVudHMgdG8gUkVQTEhpc3RvcnlcbiAqIEByZXR1cm5zIEhUTUwgZGl2IHJlcHJlc2VudGluZyBjb21tYW5kIGhpc3RvcnkgbG9nXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBSRVBMSGlzdG9yeShwcm9wczogUkVQTEhpc3RvcnlQcm9wcykge1xuICAvLyBUaGlzIGNvZGUgdGVsbHMgUmVhY3QgdG8gc2Nyb2xsIHRvIHRoZSBib3R0b20gb2YgdGhlIFJFUExIaXN0b3J5IGNvbXBvbmVudFxuICBjb25zdCBtZXNzYWdlc0VuZFJlZiA9IHVzZVJlZjxudWxsIHwgSFRNTERpdkVsZW1lbnQ+KG51bGwpO1xuICBjb25zdCBzY3JvbGxUb0JvdHRvbSA9ICgpID0+IHtcbiAgICBtZXNzYWdlc0VuZFJlZi5jdXJyZW50Py5zY3JvbGxJbnRvVmlldyh7IGJlaGF2aW9yOiBcInNtb290aFwiIH0pO1xuICB9O1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHNjcm9sbFRvQm90dG9tKCk7XG4gIH0sIFtwcm9wcy5oaXN0b3J5XSk7XG5cbiAgLyoqXG4gICAqIFRoaXMgY29kZSBtYXBzIGVhY2ggY29tbWFuZCB0byBhbiBIVE1MIGRpdiB3aXRoIGl0cyBjb21tYW5kIGluZm9ybWF0aW9uIGFuZFxuICAgKiBvdXRwdXQgYXMgYSB0YWJsZSwgZGVwZW5kaW5nIG9uIHdoYXQgbW9kZSB0aGUgYXBwIGlzIGluIChicmllZi92ZXJib3NlKVxuICAgKi9cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJlcGwtaGlzdG9yeVwiPlxuICAgICAge3Byb3BzLmhpc3RvcnkubWFwKChjb21tYW5kLCBpbmRleCkgPT5cbiAgICAgICAgcHJvcHMubW9kZSA/IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxlZnRBbGlnblwiPlxuICAgICAgICAgICAgPHAgYXJpYS1sYWJlbD17XCJjb21tYW5kTWVzc2FnZVwiICsgU3RyaW5nKGluZGV4KX0+XG4gICAgICAgICAgICAgIHtjb21tYW5kLm1lc3NhZ2V9XG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8Q3N2VGFibGUgZGF0YT17Y29tbWFuZC5kYXRhfSAvPlxuICAgICAgICAgICAgPGJyIC8+XG4gICAgICAgICAgICA8aHIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxlZnRBbGlnblwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYm9sZFRleHRcIj5Db21tYW5kOiA8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBhcmlhLWxhYmVsPXtcImNvbW1hbmRTdHJpbmdcIiArIFN0cmluZyhpbmRleCl9PlxuICAgICAgICAgICAgICB7Y29tbWFuZC5jb21tYW5kU3RyaW5nfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPGJyIC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJib2xkVGV4dFwiPk91cHR1dDogPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gYXJpYS1sYWJlbD17XCJjb21tYW5kTWVzc2FnZVwiICsgU3RyaW5nKGluZGV4KX0+XG4gICAgICAgICAgICAgIHtjb21tYW5kLm1lc3NhZ2V9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBhcmlhLWxhYmVsPXtcImRhdGFcIiArIFN0cmluZyhpbmRleCl9PlxuICAgICAgICAgICAgICA8Q3N2VGFibGUgZGF0YT17Y29tbWFuZC5kYXRhfSAvPlxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPGJyIC8+XG4gICAgICAgICAgICA8aHIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKVxuICAgICAgKX1cbiAgICAgIDxkaXYgcmVmPXttZXNzYWdlc0VuZFJlZn0gLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2lsYW5hL0Rlc2t0b3AvQnJvd24vQ1MzMi9tb2NrLWluZ3V5ZW40LXNyaWRsZXkvbW9jay9zcmMvY29tcG9uZW50cy9SRVBMSGlzdG9yeS50c3gifQ==