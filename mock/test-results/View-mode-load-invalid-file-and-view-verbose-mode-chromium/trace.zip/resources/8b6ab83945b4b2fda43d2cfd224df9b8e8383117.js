import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=797e586e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=797e586e"; const useState = __vite__cjsImport4_react["useState"];
import { ControlledInput } from "/src/components/ControlledInput.tsx";
import { load } from "/src/functions/Load.ts";
import { Command } from "/src/functions/Command.ts";
import { view } from "/src/functions/View.ts";
import { search } from "/src/functions/Search.ts";
export function REPLInput(props) {
  _s();
  const [commandString, setCommandString] = useState("");
  const [count, setCount] = useState(0);
  const [filepath, setFilepath] = useState("");
  const [hasHeader, setHeader] = useState(true);
  const handleKey = (e) => {
    if (e.key === "Enter") {
      if (!commandString) {
        return;
      }
      handleSubmit(commandString);
    }
  };
  function handleSubmit(commandString2) {
    let commandArr = commandString2.split(" ");
    let command = commandArr[0];
    let newCommand;
    if (command === "mode") {
      props.setMode(!props.mode);
      newCommand = new Command(commandString2, [], "Mode success!");
    } else if (command === "load_file") {
      if (commandArr.length >= 4 || commandArr.length <= 1) {
        newCommand = new Command(commandString2, [], "Error: incorrect number of arguments given to load_file command");
      } else {
        let loadMessage = load(commandArr, setHeader);
        newCommand = new Command(commandString2, [], loadMessage);
        setFilepath(commandArr[1]);
      }
    } else if (command === "view") {
      newCommand = view(filepath, commandString2);
    } else if (command === "search") {
      newCommand = search(filepath, hasHeader, commandString2);
    } else {
      newCommand = new Command(commandString2, [], "Error: Please provide a valid command. Valid commands: mode, load_file <csv-file-path>, view, or search <column> <value>");
    }
    setCount(count + 1);
    props.setHistory([...props.history, newCommand]);
    setCommandString("");
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-input", onKeyDown: handleKey, children: [
    /* @__PURE__ */ jsxDEV("fieldset", { children: [
      /* @__PURE__ */ jsxDEV("legend", { "aria-label": "legend", children: "Enter a command: mode, load_file <csv-file-path>, view, or search <column> <value>" }, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLInput.tsx",
        lineNumber: 93,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ControlledInput, { value: commandString, setValue: setCommandString, ariaLabel: "Command input" }, void 0, false, {
        fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLInput.tsx",
        lineNumber: 97,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLInput.tsx",
      lineNumber: 92,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLInput.tsx",
      lineNumber: 99,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: () => handleSubmit(commandString), children: [
      "Submitted ",
      count,
      " times"
    ] }, void 0, true, {
      fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLInput.tsx",
      lineNumber: 100,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLInput.tsx",
    lineNumber: 91,
    columnNumber: 10
  }, this);
}
_s(REPLInput, "PeSC00mqy/B3LnONcDmk0sduK0E=");
_c = REPLInput;
var _c;
$RefreshReg$(_c, "REPLInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/ilana/Desktop/Brown/CS32/mock-inguyen4-sridley/mock/src/components/REPLInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUdROzs7Ozs7Ozs7Ozs7Ozs7OztBQW5HUixPQUFPO0FBQ1AsU0FBbUNBLGdCQUFnQjtBQUNuRCxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLFlBQVk7QUFDckIsU0FBU0MsY0FBYztBQXlCaEIsZ0JBQVNDLFVBQVVDLE9BQXVCO0FBQUFDLEtBQUE7QUFFL0MsUUFBTSxDQUFDQyxlQUFlQyxnQkFBZ0IsSUFBSVYsU0FBaUIsRUFBRTtBQUM3RCxRQUFNLENBQUNXLE9BQU9DLFFBQVEsSUFBSVosU0FBaUIsQ0FBQztBQUM1QyxRQUFNLENBQUNhLFVBQVVDLFdBQVcsSUFBSWQsU0FBaUIsRUFBRTtBQUNuRCxRQUFNLENBQUNlLFdBQVdDLFNBQVMsSUFBSWhCLFNBQWtCLElBQUk7QUFHckQsUUFBTWlCLFlBQVlBLENBQUNDLE1BQVc7QUFDNUIsUUFBSUEsRUFBRUMsUUFBUSxTQUFTO0FBQ3JCLFVBQUksQ0FBQ1YsZUFBZTtBQUNsQjtBQUFBLE1BQ0Y7QUFDQVcsbUJBQWFYLGFBQWE7QUFBQSxJQUM1QjtBQUFBLEVBQ0Y7QUFJQSxXQUFTVyxhQUFhWCxnQkFBdUI7QUFDM0MsUUFBSVksYUFBNEJaLGVBQWNhLE1BQU0sR0FBRztBQUN2RCxRQUFJQyxVQUFrQkYsV0FBVyxDQUFDO0FBQ2xDLFFBQUlHO0FBQ0osUUFBSUQsWUFBWSxRQUFRO0FBRXRCaEIsWUFBTWtCLFFBQVEsQ0FBQ2xCLE1BQU1tQixJQUFJO0FBQ3pCRixtQkFBYSxJQUFJckIsUUFBUU0sZ0JBQWUsSUFBSSxlQUFlO0FBQUEsSUFDN0QsV0FBV2MsWUFBWSxhQUFhO0FBRWxDLFVBQUlGLFdBQVdNLFVBQVUsS0FBS04sV0FBV00sVUFBVSxHQUFHO0FBQ3BESCxxQkFBYSxJQUFJckIsUUFDZk0sZ0JBQ0EsSUFDQSxpRUFDRjtBQUFBLE1BQ0YsT0FBTztBQUNMLFlBQUltQixjQUFzQjFCLEtBQUttQixZQUFZTCxTQUFTO0FBQ3BEUSxxQkFBYSxJQUFJckIsUUFBUU0sZ0JBQWUsSUFBSW1CLFdBQVc7QUFDdkRkLG9CQUFZTyxXQUFXLENBQUMsQ0FBQztBQUFBLE1BQzNCO0FBQUEsSUFDRixXQUFXRSxZQUFZLFFBQVE7QUFFN0JDLG1CQUFhcEIsS0FBS1MsVUFBVUosY0FBYTtBQUFBLElBQzNDLFdBQVdjLFlBQVksVUFBVTtBQUUvQkMsbUJBQWFuQixPQUFPUSxVQUFVRSxXQUFXTixjQUFhO0FBQUEsSUFDeEQsT0FBTztBQUVMZSxtQkFBYSxJQUFJckIsUUFDZk0sZ0JBQ0EsSUFDQSwwSEFDRjtBQUFBLElBQ0Y7QUFHQUcsYUFBU0QsUUFBUSxDQUFDO0FBQ2xCSixVQUFNc0IsV0FBVyxDQUFDLEdBQUd0QixNQUFNdUIsU0FBU04sVUFBVSxDQUFDO0FBQy9DZCxxQkFBaUIsRUFBRTtBQUFBLEVBQ3JCO0FBTUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsY0FBYSxXQUFXTyxXQUNyQztBQUFBLDJCQUFDLGNBQ0M7QUFBQSw2QkFBQyxZQUFPLGNBQVcsVUFBUSxrR0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxtQkFDQyxPQUFPUixlQUNQLFVBQVVDLGtCQUNWLFdBQVcsbUJBSGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUc2QjtBQUFBLFNBUi9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBQ0EsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUc7QUFBQSxJQUNILHVCQUFDLFlBQU8sU0FBUyxNQUFNVSxhQUFhWCxhQUFhLEdBQUU7QUFBQTtBQUFBLE1BQ3RDRTtBQUFBQSxNQUFNO0FBQUEsU0FEbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ0JBO0FBRUo7QUFBQ0gsR0FwRmVGLFdBQVM7QUFBQXlCLEtBQVR6QjtBQUFTLElBQUF5QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJDb250cm9sbGVkSW5wdXQiLCJsb2FkIiwiQ29tbWFuZCIsInZpZXciLCJzZWFyY2giLCJSRVBMSW5wdXQiLCJwcm9wcyIsIl9zIiwiY29tbWFuZFN0cmluZyIsInNldENvbW1hbmRTdHJpbmciLCJjb3VudCIsInNldENvdW50IiwiZmlsZXBhdGgiLCJzZXRGaWxlcGF0aCIsImhhc0hlYWRlciIsInNldEhlYWRlciIsImhhbmRsZUtleSIsImUiLCJrZXkiLCJoYW5kbGVTdWJtaXQiLCJjb21tYW5kQXJyIiwic3BsaXQiLCJjb21tYW5kIiwibmV3Q29tbWFuZCIsInNldE1vZGUiLCJtb2RlIiwibGVuZ3RoIiwibG9hZE1lc3NhZ2UiLCJzZXRIaXN0b3J5IiwiaGlzdG9yeSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVQTElucHV0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgXCIuLi9zdHlsZXMvbWFpbi5jc3NcIjtcbmltcG9ydCB7IERpc3BhdGNoLCBTZXRTdGF0ZUFjdGlvbiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IENvbnRyb2xsZWRJbnB1dCB9IGZyb20gXCIuL0NvbnRyb2xsZWRJbnB1dFwiO1xuaW1wb3J0IHsgbG9hZCB9IGZyb20gXCIuLi9mdW5jdGlvbnMvTG9hZFwiO1xuaW1wb3J0IHsgQ29tbWFuZCB9IGZyb20gXCIuLi9mdW5jdGlvbnMvQ29tbWFuZFwiO1xuaW1wb3J0IHsgdmlldyB9IGZyb20gXCIuLi9mdW5jdGlvbnMvVmlld1wiO1xuaW1wb3J0IHsgc2VhcmNoIH0gZnJvbSBcIi4uL2Z1bmN0aW9ucy9TZWFyY2hcIjtcblxuLyoqXG4gKiBUaGVzZSBhcmUgdGhlIHByb3BzIGZvciB0aGUgUkVQTElucHV0IGNvbXBvbmVudC5cbiAqIC0gaGlzdG9yeSBpcyBhIGxpc3Qgb2YgYWxsIGNvbW1hbmRzIHRoYXQgaGF2ZSBiZWVuIHB1c2hlZCBieSB0aGUgdXNlciBpbiB0aGlzIHNlc3Npb25cbiAqIC0gbW9kZSBpcyBhIGJvb2xlYW4gc2V0IHRvIHRydWUgaWYgaW4gYnJpZWYgbW9kZSAoZGVmYXVsdCksIGFuZCBmYWxzZSBpbiB2ZXJib3NlIG1vZGVcbiAqIC0gc2V0SGlzdG9yeSBpcyBhIGZ1bmN0aW9uIHRoYXQgYWxsb3dzIHRoZSBjYWxsZXIgdG8gc2V0IHRoZSB2YWx1ZSBvZiB0aGUgaGlzdG9yeSBhcnJheVxuICogLSBzZXRNb2RlIGlzIGEgZnVuY3Rpb24gdGhhdCBhbGxvd3MgdGhlIGNhbGxlciB0byBzZXQgdGhlIHZhbHVlIG9mIG1vZGVcbiAqL1xuaW50ZXJmYWNlIFJFUExJbnB1dFByb3BzIHtcbiAgaGlzdG9yeTogQ29tbWFuZFtdO1xuICBtb2RlOiBib29sZWFuO1xuICBzZXRIaXN0b3J5OiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxDb21tYW5kW10+PjtcbiAgc2V0TW9kZTogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248Ym9vbGVhbj4+O1xufVxuXG4vKipcbiAqIFRoaXMgY29tcG9uZW50IGlzIGNhbGxlZCBhcyBwYXJ0IG9mIHRoZSBSRVBMIGNvbXBvbmVudC5cbiAqIFRoZSBSRVBMSW5wdXQgY29tcG9uZW50IHVzZXMgYSB0ZXh0IGlucHV0IGJhciBhbmQgYSBzdWJtaXQgYnV0dG9uIHRvIGFsbG93IHRoZSB1c2VyXG4gKiB0byBlbnRlciBjb21tYW5kcyBpbiB0aGUgaW5wdXQgYm94IGFuZCBzZW5kIHRoZW0gd2l0aCB0aGUgc3VibWl0IGJ1dHRvbi4gVGhlIFJFUExIaXN0b3J5XG4gKiBjb21wb25lbnQgaXMgdXBkYXRlZCBhY2NvcmRpbmcgdG8gdGhlIHJlc3VsdHMgb2YgdGhlc2UgY29tbWFuZHMuXG4gKiBWYWxpZCBjb21tYW5kcyBpbmNsdWRlIG1vZGUsIGxvYWRfZmlsZSA8Y3N2LWZpbGUtcGF0aD4sIHZpZXcsIGFuZCBzZWFyY2ggPGNvbHVtbj4gPHZhbHVlPlxuICogQHBhcmFtIHByb3BzIGlzIHRoZSBpbnRlcmZhY2UgYWJvdmUgY29udGFpbmluZyB0aGUgYXJndW1lbnRzIHRvIFJFUExJbnB1dFxuICogQHJldHVybnMgSFRNTCBkaXYgcmVwcmVzZW50aW5nIGlucHV0IGFyZWEsIHdpdGggaW5wdXQgYm94IGFuZCBzdWJtaXQgYnV0dG9uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBSRVBMSW5wdXQocHJvcHM6IFJFUExJbnB1dFByb3BzKSB7XG4gIC8vIFRoZXNlIGNvbnN0YW50cyBtYW5hZ2UgdGhlIHN0YXRlIHRoYXQgc3ViLWNvbXBvbmVudHMgaGF2ZSBhY2Nlc3MgdG9cbiAgY29uc3QgW2NvbW1hbmRTdHJpbmcsIHNldENvbW1hbmRTdHJpbmddID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcbiAgY29uc3QgW2NvdW50LCBzZXRDb3VudF0gPSB1c2VTdGF0ZTxudW1iZXI+KDApO1xuICBjb25zdCBbZmlsZXBhdGgsIHNldEZpbGVwYXRoXSA9IHVzZVN0YXRlPHN0cmluZz4oXCJcIik7XG4gIGNvbnN0IFtoYXNIZWFkZXIsIHNldEhlYWRlcl0gPSB1c2VTdGF0ZTxib29sZWFuPih0cnVlKTtcblxuICAvLyBUaGlzIGZ1bmN0aW9uIGVuYWJsZXMgdGhlIGNvbW1hbmQgdG8gYmUgc2VudCB3aGVuIHRoZSByZXR1cm4ga2V5IGlzIHByZXNzZWQuXG4gIGNvbnN0IGhhbmRsZUtleSA9IChlOiBhbnkpID0+IHtcbiAgICBpZiAoZS5rZXkgPT09IFwiRW50ZXJcIikge1xuICAgICAgaWYgKCFjb21tYW5kU3RyaW5nKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGhhbmRsZVN1Ym1pdChjb21tYW5kU3RyaW5nKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gVGhpcyBmdW5jdGlvbiBpcyB0cmlnZ2VyZWQgd2hlbiB0aGUgYnV0dG9uIGlzIGNsaWNrZWRcbiAgLy8gSXQgZGVwZW5kaW5nIG9uIHRoZSBjb21tYW5kIHRleHQsIGl0IGNyZWF0ZXMgYSBDb21tYW5kIG9iamVjdFxuICBmdW5jdGlvbiBoYW5kbGVTdWJtaXQoY29tbWFuZFN0cmluZzogc3RyaW5nKSB7XG4gICAgbGV0IGNvbW1hbmRBcnI6IEFycmF5PHN0cmluZz4gPSBjb21tYW5kU3RyaW5nLnNwbGl0KFwiIFwiKTtcbiAgICBsZXQgY29tbWFuZDogU3RyaW5nID0gY29tbWFuZEFyclswXTtcbiAgICBsZXQgbmV3Q29tbWFuZDogQ29tbWFuZDtcbiAgICBpZiAoY29tbWFuZCA9PT0gXCJtb2RlXCIpIHtcbiAgICAgIC8vIG1vZGVcbiAgICAgIHByb3BzLnNldE1vZGUoIXByb3BzLm1vZGUpO1xuICAgICAgbmV3Q29tbWFuZCA9IG5ldyBDb21tYW5kKGNvbW1hbmRTdHJpbmcsIFtdLCBcIk1vZGUgc3VjY2VzcyFcIik7XG4gICAgfSBlbHNlIGlmIChjb21tYW5kID09PSBcImxvYWRfZmlsZVwiKSB7XG4gICAgICAvL2xvYWRcbiAgICAgIGlmIChjb21tYW5kQXJyLmxlbmd0aCA+PSA0IHx8IGNvbW1hbmRBcnIubGVuZ3RoIDw9IDEpIHtcbiAgICAgICAgbmV3Q29tbWFuZCA9IG5ldyBDb21tYW5kKFxuICAgICAgICAgIGNvbW1hbmRTdHJpbmcsXG4gICAgICAgICAgW10sXG4gICAgICAgICAgXCJFcnJvcjogaW5jb3JyZWN0IG51bWJlciBvZiBhcmd1bWVudHMgZ2l2ZW4gdG8gbG9hZF9maWxlIGNvbW1hbmRcIlxuICAgICAgICApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbGV0IGxvYWRNZXNzYWdlOiBzdHJpbmcgPSBsb2FkKGNvbW1hbmRBcnIsIHNldEhlYWRlcik7XG4gICAgICAgIG5ld0NvbW1hbmQgPSBuZXcgQ29tbWFuZChjb21tYW5kU3RyaW5nLCBbXSwgbG9hZE1lc3NhZ2UpO1xuICAgICAgICBzZXRGaWxlcGF0aChjb21tYW5kQXJyWzFdKTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGNvbW1hbmQgPT09IFwidmlld1wiKSB7XG4gICAgICAvLyB2aWV3XG4gICAgICBuZXdDb21tYW5kID0gdmlldyhmaWxlcGF0aCwgY29tbWFuZFN0cmluZyk7XG4gICAgfSBlbHNlIGlmIChjb21tYW5kID09PSBcInNlYXJjaFwiKSB7XG4gICAgICAvLyBzZWFyY2hcbiAgICAgIG5ld0NvbW1hbmQgPSBzZWFyY2goZmlsZXBhdGgsIGhhc0hlYWRlciwgY29tbWFuZFN0cmluZyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIHVucmVjb2duaXplZCBjb21tYW5kXG4gICAgICBuZXdDb21tYW5kID0gbmV3IENvbW1hbmQoXG4gICAgICAgIGNvbW1hbmRTdHJpbmcsXG4gICAgICAgIFtdLFxuICAgICAgICBcIkVycm9yOiBQbGVhc2UgcHJvdmlkZSBhIHZhbGlkIGNvbW1hbmQuIFZhbGlkIGNvbW1hbmRzOiBtb2RlLCBsb2FkX2ZpbGUgPGNzdi1maWxlLXBhdGg+LCB2aWV3LCBvciBzZWFyY2ggPGNvbHVtbj4gPHZhbHVlPlwiXG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIFVwZGF0ZSBzdGF0ZVxuICAgIHNldENvdW50KGNvdW50ICsgMSk7XG4gICAgcHJvcHMuc2V0SGlzdG9yeShbLi4ucHJvcHMuaGlzdG9yeSwgbmV3Q29tbWFuZF0pO1xuICAgIHNldENvbW1hbmRTdHJpbmcoXCJcIik7XG4gIH1cbiAgLyoqXG4gICAqIFRoaXMgcmV0dXJucyB0aGUgbGVnZW5kLCBpbnB1dCBib3gsIGFuZCBzdWJtaXQgYnV0dG9uIHRoYXQgYWxsb3cgdGhlIHVzZXIgdG9cbiAgICogc2VuZCBjb21tYW5kcyBhbmQgdXBkYXRlIHRoZSBhcHAncyBzdGF0ZSwgc28gdGhhdCBjb21tYW5kcyBjYW4gYmUgZGlzcGxheWVkIGJ5XG4gICAqIHRoZSBSRVBMSGlzdG9yeSBjb21wb25lbnQuXG4gICAqL1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmVwbC1pbnB1dFwiIG9uS2V5RG93bj17aGFuZGxlS2V5fT5cbiAgICAgIDxmaWVsZHNldD5cbiAgICAgICAgPGxlZ2VuZCBhcmlhLWxhYmVsPVwibGVnZW5kXCI+XG4gICAgICAgICAgRW50ZXIgYSBjb21tYW5kOiBtb2RlLCBsb2FkX2ZpbGUgJmx0O2Nzdi1maWxlLXBhdGgmZ3Q7LCB2aWV3LCBvclxuICAgICAgICAgIHNlYXJjaCAmbHQ7Y29sdW1uJmd0OyAmbHQ7dmFsdWUmZ3Q7XG4gICAgICAgIDwvbGVnZW5kPlxuICAgICAgICA8Q29udHJvbGxlZElucHV0XG4gICAgICAgICAgdmFsdWU9e2NvbW1hbmRTdHJpbmd9XG4gICAgICAgICAgc2V0VmFsdWU9e3NldENvbW1hbmRTdHJpbmd9XG4gICAgICAgICAgYXJpYUxhYmVsPXtcIkNvbW1hbmQgaW5wdXRcIn1cbiAgICAgICAgLz5cbiAgICAgIDwvZmllbGRzZXQ+XG4gICAgICA8YnIgLz5cbiAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gaGFuZGxlU3VibWl0KGNvbW1hbmRTdHJpbmcpfT5cbiAgICAgICAgU3VibWl0dGVkIHtjb3VudH0gdGltZXNcbiAgICAgIDwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvaWxhbmEvRGVza3RvcC9Ccm93bi9DUzMyL21vY2staW5ndXllbjQtc3JpZGxleS9tb2NrL3NyYy9jb21wb25lbnRzL1JFUExJbnB1dC50c3gifQ==