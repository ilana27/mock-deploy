import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0f828a61"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sarahridley/Desktop/Fall 2023/CSCI 0320/mock-inguyen4-sridley/mock/src/components/REPLInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=0f828a61"; const useState = __vite__cjsImport4_react["useState"];
import { ControlledInput } from "/src/components/ControlledInput.tsx";
import { load } from "/src/functions/Load.ts";
import { Command } from "/src/components/REPL.tsx";
import { view } from "/src/functions/View.ts";
import { search } from "/src/functions/Search.ts";
export function REPLInput(props) {
  _s();
  const [commandString, setCommandString] = useState("");
  const [count, setCount] = useState(0);
  const [filepath, setFilepath] = useState("");
  const [hasHeader, setHeader] = useState(true);
  const handleKey = (e) => {
    if (e.key === "Enter") {
      if (!commandString) {
        return;
      }
      handleSubmit(commandString);
    }
  };
  function handleSubmit(commandString2) {
    let commandArr = commandString2.split(" ");
    let command = commandArr[0];
    let newCommand;
    if (command === "mode") {
      props.setMode(!props.mode);
      newCommand = new Command(commandString2, [], "Mode success!");
    } else if (command === "load_file") {
      if (commandArr.length !== 2) {
        newCommand = new Command(commandString2, [], "Error: incorrect number of arguments given to load_file command");
      } else {
        let loadMessage = load(commandArr, setHeader);
        newCommand = new Command(commandString2, [], loadMessage);
        setFilepath(commandArr[1]);
      }
    } else if (command === "view") {
      newCommand = view(filepath, commandString2);
    } else if (command === "search") {
      newCommand = search(filepath, hasHeader, commandString2);
    } else {
      newCommand = new Command(commandString2, [], "Please provide a valid command. Valid commands: mode, load_file, view, or search <column><value>");
    }
    setCount(count + 1);
    props.setHistory([...props.history, newCommand]);
    setCommandString("");
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-input", onKeyDown: handleKey, children: [
    /* @__PURE__ */ jsxDEV("fieldset", { children: [
      /* @__PURE__ */ jsxDEV("legend", { children: "Enter a command:" }, void 0, false, {
        fileName: "/Users/sarahridley/Desktop/Fall 2023/CSCI 0320/mock-inguyen4-sridley/mock/src/components/REPLInput.tsx",
        lineNumber: 78,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ControlledInput, { value: commandString, setValue: setCommandString, ariaLabel: "Command input" }, void 0, false, {
        fileName: "/Users/sarahridley/Desktop/Fall 2023/CSCI 0320/mock-inguyen4-sridley/mock/src/components/REPLInput.tsx",
        lineNumber: 79,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/sarahridley/Desktop/Fall 2023/CSCI 0320/mock-inguyen4-sridley/mock/src/components/REPLInput.tsx",
      lineNumber: 77,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "/Users/sarahridley/Desktop/Fall 2023/CSCI 0320/mock-inguyen4-sridley/mock/src/components/REPLInput.tsx",
      lineNumber: 83,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: () => handleSubmit(commandString), children: [
      "Submitted ",
      count,
      " times"
    ] }, void 0, true, {
      fileName: "/Users/sarahridley/Desktop/Fall 2023/CSCI 0320/mock-inguyen4-sridley/mock/src/components/REPLInput.tsx",
      lineNumber: 84,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/sarahridley/Desktop/Fall 2023/CSCI 0320/mock-inguyen4-sridley/mock/src/components/REPLInput.tsx",
    lineNumber: 72,
    columnNumber: 10
  }, this);
}
_s(REPLInput, "PeSC00mqy/B3LnONcDmk0sduK0E=");
_c = REPLInput;
var _c;
$RefreshReg$(_c, "REPLInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sarahridley/Desktop/Fall 2023/CSCI 0320/mock-inguyen4-sridley/mock/src/components/REPLInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUZROzs7Ozs7Ozs7Ozs7Ozs7OztBQXZGUixPQUFPO0FBQ1AsU0FBbUNBLGdCQUFnQjtBQUNuRCxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLFlBQVk7QUFDckIsU0FBU0MsY0FBYztBQVdoQixnQkFBU0MsVUFBVUMsT0FBdUI7QUFBQUMsS0FBQTtBQUcvQyxRQUFNLENBQUNDLGVBQWVDLGdCQUFnQixJQUFJVixTQUFpQixFQUFFO0FBRTdELFFBQU0sQ0FBQ1csT0FBT0MsUUFBUSxJQUFJWixTQUFpQixDQUFDO0FBQzVDLFFBQU0sQ0FBQ2EsVUFBVUMsV0FBVyxJQUFJZCxTQUFpQixFQUFFO0FBQ25ELFFBQU0sQ0FBQ2UsV0FBV0MsU0FBUyxJQUFJaEIsU0FBa0IsSUFBSTtBQUVyRCxRQUFNaUIsWUFBWUEsQ0FBQ0MsTUFBVztBQUM1QixRQUFJQSxFQUFFQyxRQUFRLFNBQVM7QUFDckIsVUFBSSxDQUFDVixlQUFlO0FBQ2xCO0FBQUEsTUFDRjtBQUNBVyxtQkFBYVgsYUFBYTtBQUFBLElBQzVCO0FBQUEsRUFDRjtBQU1BLFdBQVNXLGFBQWFYLGdCQUF1QjtBQUMzQyxRQUFJWSxhQUE0QlosZUFBY2EsTUFBTSxHQUFHO0FBQ3ZELFFBQUlDLFVBQWtCRixXQUFXLENBQUM7QUFDbEMsUUFBSUc7QUFDSixRQUFJRCxZQUFZLFFBQVE7QUFDdEJoQixZQUFNa0IsUUFBUSxDQUFDbEIsTUFBTW1CLElBQUk7QUFDekJGLG1CQUFhLElBQUlyQixRQUFRTSxnQkFBZSxJQUFJLGVBQWU7QUFBQSxJQUM3RCxXQUFXYyxZQUFZLGFBQWE7QUFFbEMsVUFBSUYsV0FBV00sV0FBVyxHQUFHO0FBQzNCSCxxQkFBYSxJQUFJckIsUUFDZk0sZ0JBQ0EsSUFDQSxpRUFDRjtBQUFBLE1BQ0YsT0FBTztBQUNMLFlBQUltQixjQUFzQjFCLEtBQUttQixZQUFZTCxTQUFTO0FBQ3BEUSxxQkFBYSxJQUFJckIsUUFBUU0sZ0JBQWUsSUFBSW1CLFdBQVc7QUFDdkRkLG9CQUFZTyxXQUFXLENBQUMsQ0FBQztBQUFBLE1BQzNCO0FBQUEsSUFDRixXQUFXRSxZQUFZLFFBQVE7QUFDN0JDLG1CQUFhcEIsS0FBS1MsVUFBVUosY0FBYTtBQUFBLElBQzNDLFdBQVdjLFlBQVksVUFBVTtBQUMvQkMsbUJBQWFuQixPQUFPUSxVQUFVRSxXQUFXTixjQUFhO0FBQUEsSUFDeEQsT0FBTztBQUNMZSxtQkFBYSxJQUFJckIsUUFDZk0sZ0JBQ0EsSUFDQSxrR0FDRjtBQUFBLElBQ0Y7QUFFQUcsYUFBU0QsUUFBUSxDQUFDO0FBRWxCSixVQUFNc0IsV0FBVyxDQUFDLEdBQUd0QixNQUFNdUIsU0FBU04sVUFBVSxDQUFDO0FBQy9DZCxxQkFBaUIsRUFBRTtBQUFBLEVBQ3JCO0FBS0EsU0FDRSx1QkFBQyxTQUFJLFdBQVUsY0FBYSxXQUFXTyxXQUtyQztBQUFBLDJCQUFDLGNBQ0M7QUFBQSw2QkFBQyxZQUFPLGdDQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0I7QUFBQSxNQUN4Qix1QkFBQyxtQkFDQyxPQUFPUixlQUNQLFVBQVVDLGtCQUNWLFdBQVcsbUJBSGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUc2QjtBQUFBLFNBTC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBR0EsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUc7QUFBQSxJQUNILHVCQUFDLFlBQU8sU0FBUyxNQUFNVSxhQUFhWCxhQUFhLEdBQUU7QUFBQTtBQUFBLE1BQ3RDRTtBQUFBQSxNQUFNO0FBQUEsU0FEbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1CQTtBQUVKO0FBQUNILEdBckZlRixXQUFTO0FBQUF5QixLQUFUekI7QUFBUyxJQUFBeUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQ29udHJvbGxlZElucHV0IiwibG9hZCIsIkNvbW1hbmQiLCJ2aWV3Iiwic2VhcmNoIiwiUkVQTElucHV0IiwicHJvcHMiLCJfcyIsImNvbW1hbmRTdHJpbmciLCJzZXRDb21tYW5kU3RyaW5nIiwiY291bnQiLCJzZXRDb3VudCIsImZpbGVwYXRoIiwic2V0RmlsZXBhdGgiLCJoYXNIZWFkZXIiLCJzZXRIZWFkZXIiLCJoYW5kbGVLZXkiLCJlIiwia2V5IiwiaGFuZGxlU3VibWl0IiwiY29tbWFuZEFyciIsInNwbGl0IiwiY29tbWFuZCIsIm5ld0NvbW1hbmQiLCJzZXRNb2RlIiwibW9kZSIsImxlbmd0aCIsImxvYWRNZXNzYWdlIiwic2V0SGlzdG9yeSIsImhpc3RvcnkiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJFUExJbnB1dC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCI7XG5pbXBvcnQgeyBEaXNwYXRjaCwgU2V0U3RhdGVBY3Rpb24sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBDb250cm9sbGVkSW5wdXQgfSBmcm9tIFwiLi9Db250cm9sbGVkSW5wdXRcIjtcbmltcG9ydCB7IGxvYWQgfSBmcm9tIFwiLi4vZnVuY3Rpb25zL0xvYWRcIjtcbmltcG9ydCB7IENvbW1hbmQgfSBmcm9tIFwiLi9SRVBMXCI7XG5pbXBvcnQgeyB2aWV3IH0gZnJvbSBcIi4uL2Z1bmN0aW9ucy9WaWV3XCI7XG5pbXBvcnQgeyBzZWFyY2ggfSBmcm9tIFwiLi4vZnVuY3Rpb25zL1NlYXJjaFwiO1xuXG5pbnRlcmZhY2UgUkVQTElucHV0UHJvcHMge1xuICAvLyBUT0RPOiBGaWxsIHRoaXMgd2l0aCBkZXNpcmVkIHByb3BzLi4uIE1heWJlIHNvbWV0aGluZyB0byBrZWVwIHRyYWNrIG9mIHRoZSBzdWJtaXR0ZWQgY29tbWFuZHNcbiAgaGlzdG9yeTogQ29tbWFuZFtdO1xuICBtb2RlOiBib29sZWFuO1xuICBzZXRIaXN0b3J5OiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxDb21tYW5kW10+PjtcbiAgc2V0TW9kZTogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248Ym9vbGVhbj4+O1xufVxuLy8gWW91IGNhbiB1c2UgYSBjdXN0b20gaW50ZXJmYWNlIG9yIGV4cGxpY2l0IGZpZWxkcyBvciBib3RoISBBbiBhbHRlcm5hdGl2ZSB0byB0aGUgY3VycmVudCBmdW5jdGlvbiBoZWFkZXIgbWlnaHQgYmU6XG4vLyBSRVBMSW5wdXQoaGlzdG9yeTogc3RyaW5nW10sIHNldEhpc3Rvcnk6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPHN0cmluZ1tdPj4pXG5leHBvcnQgZnVuY3Rpb24gUkVQTElucHV0KHByb3BzOiBSRVBMSW5wdXRQcm9wcykge1xuICAvLyBSZW1lbWJlcjogbGV0IFJlYWN0IG1hbmFnZSBzdGF0ZSBpbiB5b3VyIHdlYmFwcC5cbiAgLy8gTWFuYWdlcyB0aGUgY29udGVudHMgb2YgdGhlIGlucHV0IGJveFxuICBjb25zdCBbY29tbWFuZFN0cmluZywgc2V0Q29tbWFuZFN0cmluZ10gPSB1c2VTdGF0ZTxzdHJpbmc+KFwiXCIpO1xuICAvLyBUT0RPIFdJVEggVEEgOiBhZGQgYSBjb3VudCBzdGF0ZVxuICBjb25zdCBbY291bnQsIHNldENvdW50XSA9IHVzZVN0YXRlPG51bWJlcj4oMCk7XG4gIGNvbnN0IFtmaWxlcGF0aCwgc2V0RmlsZXBhdGhdID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcbiAgY29uc3QgW2hhc0hlYWRlciwgc2V0SGVhZGVyXSA9IHVzZVN0YXRlPGJvb2xlYW4+KHRydWUpO1xuXG4gIGNvbnN0IGhhbmRsZUtleSA9IChlOiBhbnkpID0+IHtcbiAgICBpZiAoZS5rZXkgPT09IFwiRW50ZXJcIikge1xuICAgICAgaWYgKCFjb21tYW5kU3RyaW5nKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGhhbmRsZVN1Ym1pdChjb21tYW5kU3RyaW5nKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gVE9ETyBXSVRIIFRBOiBidWlsZCBhIGhhbmRsZVN1Ym1pdCBmdW5jdGlvbiBjYWxsZWQgaW4gYnV0dG9uIG9uQ2xpY2tcbiAgLy8gVE9ETzogT25jZSBpdCBpbmNyZW1lbnRzLCB0cnkgdG8gbWFrZSBpdCBwdXNoIGNvbW1hbmRzLi4uIE5vdGUgdGhhdCB5b3UgY2FuIHVzZSB0aGUgYC4uLmAgc3ByZWFkIHN5bnRheCB0byBjb3B5IHdoYXQgd2FzIHRoZXJlIGJlZm9yZVxuICAvLyBhZGQgdG8gaXQgd2l0aCBuZXcgY29tbWFuZHMuXG4gIC8vIFRoaXMgZnVuY3Rpb24gaXMgdHJpZ2dlcmVkIHdoZW4gdGhlIGJ1dHRvbiBpcyBjbGlja2VkLlxuICBmdW5jdGlvbiBoYW5kbGVTdWJtaXQoY29tbWFuZFN0cmluZzogc3RyaW5nKSB7XG4gICAgbGV0IGNvbW1hbmRBcnI6IEFycmF5PHN0cmluZz4gPSBjb21tYW5kU3RyaW5nLnNwbGl0KFwiIFwiKTtcbiAgICBsZXQgY29tbWFuZDogU3RyaW5nID0gY29tbWFuZEFyclswXTtcbiAgICBsZXQgbmV3Q29tbWFuZDogQ29tbWFuZDtcbiAgICBpZiAoY29tbWFuZCA9PT0gXCJtb2RlXCIpIHtcbiAgICAgIHByb3BzLnNldE1vZGUoIXByb3BzLm1vZGUpO1xuICAgICAgbmV3Q29tbWFuZCA9IG5ldyBDb21tYW5kKGNvbW1hbmRTdHJpbmcsIFtdLCBcIk1vZGUgc3VjY2VzcyFcIik7XG4gICAgfSBlbHNlIGlmIChjb21tYW5kID09PSBcImxvYWRfZmlsZVwiKSB7XG4gICAgICAvL2xvYWRcbiAgICAgIGlmIChjb21tYW5kQXJyLmxlbmd0aCAhPT0gMikge1xuICAgICAgICBuZXdDb21tYW5kID0gbmV3IENvbW1hbmQoXG4gICAgICAgICAgY29tbWFuZFN0cmluZyxcbiAgICAgICAgICBbXSxcbiAgICAgICAgICBcIkVycm9yOiBpbmNvcnJlY3QgbnVtYmVyIG9mIGFyZ3VtZW50cyBnaXZlbiB0byBsb2FkX2ZpbGUgY29tbWFuZFwiXG4gICAgICAgICk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBsZXQgbG9hZE1lc3NhZ2U6IHN0cmluZyA9IGxvYWQoY29tbWFuZEFyciwgc2V0SGVhZGVyKTtcbiAgICAgICAgbmV3Q29tbWFuZCA9IG5ldyBDb21tYW5kKGNvbW1hbmRTdHJpbmcsIFtdLCBsb2FkTWVzc2FnZSk7XG4gICAgICAgIHNldEZpbGVwYXRoKGNvbW1hbmRBcnJbMV0pO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoY29tbWFuZCA9PT0gXCJ2aWV3XCIpIHtcbiAgICAgIG5ld0NvbW1hbmQgPSB2aWV3KGZpbGVwYXRoLCBjb21tYW5kU3RyaW5nKTtcbiAgICB9IGVsc2UgaWYgKGNvbW1hbmQgPT09IFwic2VhcmNoXCIpIHtcbiAgICAgIG5ld0NvbW1hbmQgPSBzZWFyY2goZmlsZXBhdGgsIGhhc0hlYWRlciwgY29tbWFuZFN0cmluZyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIG5ld0NvbW1hbmQgPSBuZXcgQ29tbWFuZChcbiAgICAgICAgY29tbWFuZFN0cmluZyxcbiAgICAgICAgW10sXG4gICAgICAgIFwiUGxlYXNlIHByb3ZpZGUgYSB2YWxpZCBjb21tYW5kLiBWYWxpZCBjb21tYW5kczogbW9kZSwgbG9hZF9maWxlLCB2aWV3LCBvciBzZWFyY2ggPGNvbHVtbj48dmFsdWU+XCJcbiAgICAgICk7XG4gICAgfVxuXG4gICAgc2V0Q291bnQoY291bnQgKyAxKTtcbiAgICAvLyBDSEFOR0VEXG4gICAgcHJvcHMuc2V0SGlzdG9yeShbLi4ucHJvcHMuaGlzdG9yeSwgbmV3Q29tbWFuZF0pO1xuICAgIHNldENvbW1hbmRTdHJpbmcoXCJcIik7XG4gIH1cbiAgLyoqXG4gICAqIFdlIHN1Z2dlc3QgYnJlYWtpbmcgZG93biB0aGlzIGNvbXBvbmVudCBpbnRvIHNtYWxsZXIgY29tcG9uZW50cywgdGhpbmsgYWJvdXQgdGhlIGluZGl2aWR1YWwgcGllY2VzXG4gICAqIG9mIHRoZSBSRVBMIGFuZCBob3cgdGhleSBjb25uZWN0IHRvIGVhY2ggb3RoZXIuLi5cbiAgICovXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZXBsLWlucHV0XCIgb25LZXlEb3duPXtoYW5kbGVLZXl9PlxuICAgICAgey8qIFRoaXMgaXMgYSBjb21tZW50IHdpdGhpbiB0aGUgSlNYLiBOb3RpY2UgdGhhdCBpdCdzIGEgVHlwZVNjcmlwdCBjb21tZW50IHdyYXBwZWQgaW5cbiAgICAgICAgICAgIGJyYWNlcywgc28gdGhhdCBSZWFjdCBrbm93cyBpdCBzaG91bGQgYmUgaW50ZXJwcmV0ZWQgYXMgVHlwZVNjcmlwdCAqL31cbiAgICAgIHsvKiBJIG9wdGVkIHRvIHVzZSB0aGlzIEhUTUwgdGFnOyB5b3UgZG9uJ3QgbmVlZCB0by4gSXQgc3RydWN0dXJlcyBtdWx0aXBsZSBpbnB1dCBmaWVsZHNcbiAgICAgICAgICAgIGludG8gYSBzaW5nbGUgdW5pdCwgd2hpY2ggbWFrZXMgaXQgZWFzaWVyIGZvciBzY3JlZW5yZWFkZXJzIHRvIG5hdmlnYXRlLiAqL31cbiAgICAgIDxmaWVsZHNldD5cbiAgICAgICAgPGxlZ2VuZD5FbnRlciBhIGNvbW1hbmQ6PC9sZWdlbmQ+XG4gICAgICAgIDxDb250cm9sbGVkSW5wdXRcbiAgICAgICAgICB2YWx1ZT17Y29tbWFuZFN0cmluZ31cbiAgICAgICAgICBzZXRWYWx1ZT17c2V0Q29tbWFuZFN0cmluZ31cbiAgICAgICAgICBhcmlhTGFiZWw9e1wiQ29tbWFuZCBpbnB1dFwifVxuICAgICAgICAvPlxuICAgICAgPC9maWVsZHNldD5cbiAgICAgIHsvKiBUT0RPIFdJVEggVEE6IEJ1aWxkIGEgaGFuZGxlU3VibWl0IGZ1bmN0aW9uIHRoYXQgaW5jcmVtZW50cyBjb3VudCBhbmQgZGlzcGxheXMgdGhlIHRleHQgaW4gdGhlIGJ1dHRvbiAqL31cbiAgICAgIHsvKiBUT0RPOiBDdXJyZW50bHkgdGhpcyBidXR0b24ganVzdCBjb3VudHMgdXAsIGNhbiB3ZSBtYWtlIGl0IHB1c2ggdGhlIGNvbnRlbnRzIG9mIHRoZSBpbnB1dCBib3ggdG8gdGhlIGhpc3Rvcnk/Ki99XG4gICAgICA8YnIgLz5cbiAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gaGFuZGxlU3VibWl0KGNvbW1hbmRTdHJpbmcpfT5cbiAgICAgICAgU3VibWl0dGVkIHtjb3VudH0gdGltZXNcbiAgICAgIDwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvc2FyYWhyaWRsZXkvRGVza3RvcC9GYWxsIDIwMjMvQ1NDSSAwMzIwL21vY2staW5ndXllbjQtc3JpZGxleS9tb2NrL3NyYy9jb21wb25lbnRzL1JFUExJbnB1dC50c3gifQ==