import { Command } from "/src/components/REPL.tsx";
export function search(filepath, hasHeader, commandString) {
  let searchMap = /* @__PURE__ */ new Map([
    ["data/filepath11Thetrue", [["The", "song", "remains", "the", "same."]]],
    [
      "data/filepath2eAritrue",
      [
        ["a", "b", "c", "d", "e"],
        ["Hi", "my", "name", "is", "Ari"]
      ]
    ]
  ]);
  let commandStringSplit = commandString.split(" ");
  console.log(
    filepath + commandStringSplit[1] + commandStringSplit[2] + String(hasHeader)
  );
  let result = searchMap.get(
    filepath + commandStringSplit[1] + commandStringSplit[2] + String(hasHeader)
  );
  if (result === void 0) {
    return new Command(
      commandString,
      [],
      "Error: search unsuccessful, could not find the value in the given column."
    );
  }
  return new Command(commandString, result, "Search success");
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlNlYXJjaC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBOb3RlIHRoaXMgaXMgYSAudHMgZmlsZSwgbm90IC50c3guIEl0J3MgVHlwZVNjcmlwdCwgYnV0IG5vdCBSZWFjdC5cbmltcG9ydCB7IERpc3BhdGNoLCBTZXRTdGF0ZUFjdGlvbiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IENvbW1hbmQgfSBmcm9tIFwiLi4vY29tcG9uZW50cy9SRVBMXCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBzZWFyY2goXG4gIGZpbGVwYXRoOiBzdHJpbmcsXG4gIGhhc0hlYWRlcjogYm9vbGVhbixcbiAgY29tbWFuZFN0cmluZzogc3RyaW5nXG4pIHtcbiAgbGV0IHNlYXJjaE1hcCA9IG5ldyBNYXA8c3RyaW5nLCBzdHJpbmdbXVtdPihbXG4gICAgW1wiZGF0YS9maWxlcGF0aDExVGhldHJ1ZVwiLCBbW1wiVGhlXCIsIFwic29uZ1wiLCBcInJlbWFpbnNcIiwgXCJ0aGVcIiwgXCJzYW1lLlwiXV1dLFxuICAgIFtcbiAgICAgIFwiZGF0YS9maWxlcGF0aDJlQXJpdHJ1ZVwiLFxuICAgICAgW1xuICAgICAgICBbXCJhXCIsIFwiYlwiLCBcImNcIiwgXCJkXCIsIFwiZVwiXSxcbiAgICAgICAgW1wiSGlcIiwgXCJteVwiLCBcIm5hbWVcIiwgXCJpc1wiLCBcIkFyaVwiXSxcbiAgICAgIF0sXG4gICAgXSxcbiAgXSk7XG5cbiAgbGV0IGNvbW1hbmRTdHJpbmdTcGxpdDogc3RyaW5nW10gPSBjb21tYW5kU3RyaW5nLnNwbGl0KFwiIFwiKTtcblxuICBjb25zb2xlLmxvZyhcbiAgICBmaWxlcGF0aCArIGNvbW1hbmRTdHJpbmdTcGxpdFsxXSArIGNvbW1hbmRTdHJpbmdTcGxpdFsyXSArIFN0cmluZyhoYXNIZWFkZXIpXG4gICk7XG4gIGxldCByZXN1bHQgPSBzZWFyY2hNYXAuZ2V0KFxuICAgIGZpbGVwYXRoICsgY29tbWFuZFN0cmluZ1NwbGl0WzFdICsgY29tbWFuZFN0cmluZ1NwbGl0WzJdICsgU3RyaW5nKGhhc0hlYWRlcilcbiAgKTtcblxuICBpZiAocmVzdWx0ID09PSB1bmRlZmluZWQpIHtcbiAgICByZXR1cm4gbmV3IENvbW1hbmQoXG4gICAgICBjb21tYW5kU3RyaW5nLFxuICAgICAgW10sXG4gICAgICBcIkVycm9yOiBzZWFyY2ggdW5zdWNjZXNzZnVsLCBjb3VsZCBub3QgZmluZCB0aGUgdmFsdWUgaW4gdGhlIGdpdmVuIGNvbHVtbi5cIlxuICAgICk7XG4gIH1cbiAgcmV0dXJuIG5ldyBDb21tYW5kKGNvbW1hbmRTdHJpbmcsIHJlc3VsdCwgXCJTZWFyY2ggc3VjY2Vzc1wiKTtcbn1cbiJdLCJtYXBwaW5ncyI6IkFBRUEsU0FBUyxlQUFlO0FBRWpCLGdCQUFTLE9BQ2QsVUFDQSxXQUNBLGVBQ0E7QUFDQSxNQUFJLFlBQVksb0JBQUksSUFBd0I7QUFBQSxJQUMxQyxDQUFDLDBCQUEwQixDQUFDLENBQUMsT0FBTyxRQUFRLFdBQVcsT0FBTyxPQUFPLENBQUMsQ0FBQztBQUFBLElBQ3ZFO0FBQUEsTUFDRTtBQUFBLE1BQ0E7QUFBQSxRQUNFLENBQUMsS0FBSyxLQUFLLEtBQUssS0FBSyxHQUFHO0FBQUEsUUFDeEIsQ0FBQyxNQUFNLE1BQU0sUUFBUSxNQUFNLEtBQUs7QUFBQSxNQUNsQztBQUFBLElBQ0Y7QUFBQSxFQUNGLENBQUM7QUFFRCxNQUFJLHFCQUErQixjQUFjLE1BQU0sR0FBRztBQUUxRCxVQUFRO0FBQUEsSUFDTixXQUFXLG1CQUFtQixDQUFDLElBQUksbUJBQW1CLENBQUMsSUFBSSxPQUFPLFNBQVM7QUFBQSxFQUM3RTtBQUNBLE1BQUksU0FBUyxVQUFVO0FBQUEsSUFDckIsV0FBVyxtQkFBbUIsQ0FBQyxJQUFJLG1CQUFtQixDQUFDLElBQUksT0FBTyxTQUFTO0FBQUEsRUFDN0U7QUFFQSxNQUFJLFdBQVcsUUFBVztBQUN4QixXQUFPLElBQUk7QUFBQSxNQUNUO0FBQUEsTUFDQSxDQUFDO0FBQUEsTUFDRDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsU0FBTyxJQUFJLFFBQVEsZUFBZSxRQUFRLGdCQUFnQjtBQUM1RDsiLCJuYW1lcyI6W119