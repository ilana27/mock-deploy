import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/REPLHistory.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0f828a61"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/sarahridley/Desktop/Fall 2023/CSCI 0320/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css";
import CsvTable from "/src/components/CsvTable.tsx";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=0f828a61"; const useRef = __vite__cjsImport5_react["useRef"]; const useEffect = __vite__cjsImport5_react["useEffect"];
export function REPLHistory(props) {
  _s();
  const messagesEndRef = useRef(null);
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({
      behavior: "smooth"
    });
  };
  useEffect(() => {
    scrollToBottom();
  }, [props.history]);
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-history", children: [
    props.history.map((command, index) => props.mode ? /* @__PURE__ */ jsxDEV("div", { className: "leftAlign", children: [
      /* @__PURE__ */ jsxDEV("p", { "aria-label": "commandMessage" + String(index), children: command.message }, void 0, false, {
        fileName: "/Users/sarahridley/Desktop/Fall 2023/CSCI 0320/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
        lineNumber: 26,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(CsvTable, { data: command.data }, void 0, false, {
        fileName: "/Users/sarahridley/Desktop/Fall 2023/CSCI 0320/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
        lineNumber: 29,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/sarahridley/Desktop/Fall 2023/CSCI 0320/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
        lineNumber: 30,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
        fileName: "/Users/sarahridley/Desktop/Fall 2023/CSCI 0320/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
        lineNumber: 31,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/sarahridley/Desktop/Fall 2023/CSCI 0320/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
      lineNumber: 25,
      columnNumber: 59
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "leftAlign", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "boldText", children: "Command: " }, void 0, false, {
        fileName: "/Users/sarahridley/Desktop/Fall 2023/CSCI 0320/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
        lineNumber: 33,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("span", { "aria-label": "commandString" + String(index), children: command.commandString }, void 0, false, {
        fileName: "/Users/sarahridley/Desktop/Fall 2023/CSCI 0320/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
        lineNumber: 34,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/sarahridley/Desktop/Fall 2023/CSCI 0320/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
        lineNumber: 37,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "boldText", children: "Ouptut: " }, void 0, false, {
        fileName: "/Users/sarahridley/Desktop/Fall 2023/CSCI 0320/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
        lineNumber: 38,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("span", { "aria-label": "commandMessage" + String(index), children: command.message }, void 0, false, {
        fileName: "/Users/sarahridley/Desktop/Fall 2023/CSCI 0320/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
        lineNumber: 39,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(CsvTable, { data: command.data }, void 0, false, {
        fileName: "/Users/sarahridley/Desktop/Fall 2023/CSCI 0320/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
        lineNumber: 42,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/sarahridley/Desktop/Fall 2023/CSCI 0320/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
        lineNumber: 43,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
        fileName: "/Users/sarahridley/Desktop/Fall 2023/CSCI 0320/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
        lineNumber: 44,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/sarahridley/Desktop/Fall 2023/CSCI 0320/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
      lineNumber: 32,
      columnNumber: 20
    }, this)),
    /* @__PURE__ */ jsxDEV("div", { ref: messagesEndRef }, void 0, false, {
      fileName: "/Users/sarahridley/Desktop/Fall 2023/CSCI 0320/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
      lineNumber: 46,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/sarahridley/Desktop/Fall 2023/CSCI 0320/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx",
    lineNumber: 22,
    columnNumber: 10
  }, this);
}
_s(REPLHistory, "0epSoi03NVSoD0I0FiLK4iVNXOA=");
_c = REPLHistory;
var _c;
$RefreshReg$(_c, "REPLHistory");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/sarahridley/Desktop/Fall 2023/CSCI 0320/mock-inguyen4-sridley/mock/src/components/REPLHistory.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkJZOzs7Ozs7Ozs7Ozs7Ozs7OztBQTNCWixPQUFPO0FBQ1AsT0FBT0EsY0FBYztBQUVyQixTQUFTQyxRQUFRQyxpQkFBaUI7QUFPM0IsZ0JBQVNDLFlBQVlDLE9BQXlCO0FBQUFDLEtBQUE7QUFDbkQsUUFBTUMsaUJBQWlCTCxPQUE4QixJQUFJO0FBRXpELFFBQU1NLGlCQUFpQkEsTUFBTTtBQUMzQkQsbUJBQWVFLFNBQVNDLGVBQWU7QUFBQSxNQUFFQyxVQUFVO0FBQUEsSUFBUyxDQUFDO0FBQUEsRUFDL0Q7QUFFQVIsWUFBVSxNQUFNO0FBQ2RLLG1CQUFlO0FBQUEsRUFDakIsR0FBRyxDQUFDSCxNQUFNTyxPQUFPLENBQUM7QUFDbEIsU0FDRSx1QkFBQyxTQUFJLFdBQVUsZ0JBR1pQO0FBQUFBLFVBQU1PLFFBQVFDLElBQUksQ0FBQ0MsU0FBU0MsVUFDM0JWLE1BQU1XLE9BQ0osdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSw2QkFBQyxPQUFFLGNBQVksbUJBQW1CQyxPQUFPRixLQUFLLEdBQzNDRCxrQkFBUUksV0FEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFlBQVMsTUFBTUosUUFBUUssUUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2QjtBQUFBLE1BQzdCLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFHO0FBQUEsTUFDSCx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBRztBQUFBLFNBTkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BLElBRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSw2QkFBQyxVQUFLLFdBQVUsWUFBVyx5QkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQztBQUFBLE1BQ3BDLHVCQUFDLFVBQUssY0FBWSxrQkFBa0JGLE9BQU9GLEtBQUssR0FDN0NELGtCQUFRTSxpQkFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFHO0FBQUEsTUFDSCx1QkFBQyxVQUFLLFdBQVUsWUFBVyx3QkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtQztBQUFBLE1BQ25DLHVCQUFDLFVBQUssY0FBWSxtQkFBbUJILE9BQU9GLEtBQUssR0FDOUNELGtCQUFRSSxXQURYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsWUFBUyxNQUFNSixRQUFRSyxRQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZCO0FBQUEsTUFDN0IsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUc7QUFBQSxNQUNILHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFHO0FBQUEsU0FaTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUEsQ0FFSjtBQUFBLElBQ0EsdUJBQUMsU0FBSSxLQUFLWixrQkFBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlCO0FBQUEsT0E5QjNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErQkE7QUFFSjtBQUFDRCxHQTVDZUYsYUFBVztBQUFBaUIsS0FBWGpCO0FBQVcsSUFBQWlCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJDc3ZUYWJsZSIsInVzZVJlZiIsInVzZUVmZmVjdCIsIlJFUExIaXN0b3J5IiwicHJvcHMiLCJfcyIsIm1lc3NhZ2VzRW5kUmVmIiwic2Nyb2xsVG9Cb3R0b20iLCJjdXJyZW50Iiwic2Nyb2xsSW50b1ZpZXciLCJiZWhhdmlvciIsImhpc3RvcnkiLCJtYXAiLCJjb21tYW5kIiwiaW5kZXgiLCJtb2RlIiwiU3RyaW5nIiwibWVzc2FnZSIsImRhdGEiLCJjb21tYW5kU3RyaW5nIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSRVBMSGlzdG9yeS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCI7XG5pbXBvcnQgQ3N2VGFibGUgZnJvbSBcIi4vQ3N2VGFibGVcIjtcbmltcG9ydCB7IENvbW1hbmQgfSBmcm9tIFwiLi9SRVBMXCI7XG5pbXBvcnQgeyB1c2VSZWYsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xuXG5pbnRlcmZhY2UgUkVQTEhpc3RvcnlQcm9wcyB7XG4gIC8vIFRPRE86IEZpbGwgd2l0aCBzb21lIHNoYXJlZCBzdGF0ZSB0cmFja2luZyBhbGwgdGhlIHB1c2hlZCBjb21tYW5kc1xuICBoaXN0b3J5OiBDb21tYW5kW107XG4gIG1vZGU6IGJvb2xlYW47XG59XG5leHBvcnQgZnVuY3Rpb24gUkVQTEhpc3RvcnkocHJvcHM6IFJFUExIaXN0b3J5UHJvcHMpIHtcbiAgY29uc3QgbWVzc2FnZXNFbmRSZWYgPSB1c2VSZWY8bnVsbCB8IEhUTUxEaXZFbGVtZW50PihudWxsKTtcblxuICBjb25zdCBzY3JvbGxUb0JvdHRvbSA9ICgpID0+IHtcbiAgICBtZXNzYWdlc0VuZFJlZi5jdXJyZW50Py5zY3JvbGxJbnRvVmlldyh7IGJlaGF2aW9yOiBcInNtb290aFwiIH0pO1xuICB9O1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgc2Nyb2xsVG9Cb3R0b20oKTtcbiAgfSwgW3Byb3BzLmhpc3RvcnldKTtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJlcGwtaGlzdG9yeVwiPlxuICAgICAgey8qIFRoaXMgaXMgd2hlcmUgY29tbWFuZCBoaXN0b3J5IHdpbGwgZ28gKi99XG4gICAgICB7LyogVE9ETzogVG8gZ28gdGhyb3VnaCBhbGwgdGhlIHB1c2hlZCBjb21tYW5kcy4uLiB0cnkgdGhlIC5tYXAoKSBmdW5jdGlvbiEgKi99XG4gICAgICB7cHJvcHMuaGlzdG9yeS5tYXAoKGNvbW1hbmQsIGluZGV4KSA9PlxuICAgICAgICBwcm9wcy5tb2RlID8gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGVmdEFsaWduXCI+XG4gICAgICAgICAgICA8cCBhcmlhLWxhYmVsPXtcImNvbW1hbmRNZXNzYWdlXCIgKyBTdHJpbmcoaW5kZXgpfT5cbiAgICAgICAgICAgICAge2NvbW1hbmQubWVzc2FnZX1cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDxDc3ZUYWJsZSBkYXRhPXtjb21tYW5kLmRhdGF9IC8+XG4gICAgICAgICAgICA8YnIgLz5cbiAgICAgICAgICAgIDxociAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApIDogKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGVmdEFsaWduXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJib2xkVGV4dFwiPkNvbW1hbmQ6IDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGFyaWEtbGFiZWw9e1wiY29tbWFuZFN0cmluZ1wiICsgU3RyaW5nKGluZGV4KX0+XG4gICAgICAgICAgICAgIHtjb21tYW5kLmNvbW1hbmRTdHJpbmd9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8YnIgLz5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJvbGRUZXh0XCI+T3VwdHV0OiA8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBhcmlhLWxhYmVsPXtcImNvbW1hbmRNZXNzYWdlXCIgKyBTdHJpbmcoaW5kZXgpfT5cbiAgICAgICAgICAgICAge2NvbW1hbmQubWVzc2FnZX1cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxDc3ZUYWJsZSBkYXRhPXtjb21tYW5kLmRhdGF9IC8+XG4gICAgICAgICAgICA8YnIgLz5cbiAgICAgICAgICAgIDxociAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApXG4gICAgICApfVxuICAgICAgPGRpdiByZWY9e21lc3NhZ2VzRW5kUmVmfSAvPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvc2FyYWhyaWRsZXkvRGVza3RvcC9GYWxsIDIwMjMvQ1NDSSAwMzIwL21vY2staW5ndXllbjQtc3JpZGxleS9tb2NrL3NyYy9jb21wb25lbnRzL1JFUExIaXN0b3J5LnRzeCJ9