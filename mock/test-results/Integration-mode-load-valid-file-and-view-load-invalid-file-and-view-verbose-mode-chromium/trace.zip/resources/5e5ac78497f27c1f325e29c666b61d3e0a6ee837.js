export function load(commandArr, setHeader) {
  let filepath = commandArr[1];
  let filepathSplit = filepath.split("/");
  if (!(filepathSplit[0] === "data" || filepathSplit[0] === "." && filepathSplit[1] === "data")) {
    return "Error: filepath " + filepath + " located in an unaccessible directory.";
  }
  if (commandArr.length > 2) {
    let hasHeader = commandArr[2];
    if (hasHeader.toLowerCase() === "true") {
      setHeader(true);
    } else if (hasHeader.toLowerCase() === "false") {
      setHeader(false);
    } else {
      return "Error: header parameter must be either true or false.";
    }
  }
  let validFiles = [
    "data/filepath1",
    "data/filepath2",
    "data/ten-star.csv",
    "data/ten-star_no_headings.csv",
    "data/empty.csv"
  ];
  if (validFiles.includes(filepath)) {
    return "Load success!";
  }
  return "Error: " + filepath + " not found";
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkxvYWQudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gTm90ZSB0aGlzIGlzIGEgLnRzIGZpbGUsIG5vdCAudHN4LiBJdCdzIFR5cGVTY3JpcHQsIGJ1dCBub3QgUmVhY3QuXG5pbXBvcnQgeyBEaXNwYXRjaCwgU2V0U3RhdGVBY3Rpb24sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5cbi8qKlxuICpcbiAqXG4gKlxuICovXG5leHBvcnQgZnVuY3Rpb24gbG9hZChcbiAgY29tbWFuZEFycjogc3RyaW5nW10sXG4gIHNldEhlYWRlcjogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248Ym9vbGVhbj4+XG4pIHtcbiAgbGV0IGZpbGVwYXRoID0gY29tbWFuZEFyclsxXTtcbiAgbGV0IGZpbGVwYXRoU3BsaXQ6IHN0cmluZ1tdID0gZmlsZXBhdGguc3BsaXQoXCIvXCIpO1xuICBpZiAoXG4gICAgIShcbiAgICAgIGZpbGVwYXRoU3BsaXRbMF0gPT09IFwiZGF0YVwiIHx8XG4gICAgICAoZmlsZXBhdGhTcGxpdFswXSA9PT0gXCIuXCIgJiYgZmlsZXBhdGhTcGxpdFsxXSA9PT0gXCJkYXRhXCIpXG4gICAgKVxuICApIHtcbiAgICByZXR1cm4gKFxuICAgICAgXCJFcnJvcjogZmlsZXBhdGggXCIgKyBmaWxlcGF0aCArIFwiIGxvY2F0ZWQgaW4gYW4gdW5hY2Nlc3NpYmxlIGRpcmVjdG9yeS5cIlxuICAgICk7XG4gIH1cbiAgaWYgKGNvbW1hbmRBcnIubGVuZ3RoID4gMikge1xuICAgIGxldCBoYXNIZWFkZXIgPSBjb21tYW5kQXJyWzJdO1xuICAgIGlmIChoYXNIZWFkZXIudG9Mb3dlckNhc2UoKSA9PT0gXCJ0cnVlXCIpIHtcbiAgICAgIHNldEhlYWRlcih0cnVlKTtcbiAgICB9IGVsc2UgaWYgKGhhc0hlYWRlci50b0xvd2VyQ2FzZSgpID09PSBcImZhbHNlXCIpIHtcbiAgICAgIHNldEhlYWRlcihmYWxzZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBcIkVycm9yOiBoZWFkZXIgcGFyYW1ldGVyIG11c3QgYmUgZWl0aGVyIHRydWUgb3IgZmFsc2UuXCI7XG4gICAgfVxuICB9XG4gIGxldCB2YWxpZEZpbGVzOiBzdHJpbmdbXSA9IFtcbiAgICBcImRhdGEvZmlsZXBhdGgxXCIsXG4gICAgXCJkYXRhL2ZpbGVwYXRoMlwiLFxuICAgIFwiZGF0YS90ZW4tc3Rhci5jc3ZcIixcbiAgICBcImRhdGEvdGVuLXN0YXJfbm9faGVhZGluZ3MuY3N2XCIsXG4gICAgXCJkYXRhL2VtcHR5LmNzdlwiLFxuICBdO1xuICBpZiAodmFsaWRGaWxlcy5pbmNsdWRlcyhmaWxlcGF0aCkpIHtcbiAgICByZXR1cm4gXCJMb2FkIHN1Y2Nlc3MhXCI7XG4gIH1cbiAgcmV0dXJuIFwiRXJyb3I6IFwiICsgZmlsZXBhdGggKyBcIiBub3QgZm91bmRcIjtcbn1cbiJdLCJtYXBwaW5ncyI6IkFBUU8sZ0JBQVMsS0FDZCxZQUNBLFdBQ0E7QUFDQSxNQUFJLFdBQVcsV0FBVyxDQUFDO0FBQzNCLE1BQUksZ0JBQTBCLFNBQVMsTUFBTSxHQUFHO0FBQ2hELE1BQ0UsRUFDRSxjQUFjLENBQUMsTUFBTSxVQUNwQixjQUFjLENBQUMsTUFBTSxPQUFPLGNBQWMsQ0FBQyxNQUFNLFNBRXBEO0FBQ0EsV0FDRSxxQkFBcUIsV0FBVztBQUFBLEVBRXBDO0FBQ0EsTUFBSSxXQUFXLFNBQVMsR0FBRztBQUN6QixRQUFJLFlBQVksV0FBVyxDQUFDO0FBQzVCLFFBQUksVUFBVSxZQUFZLE1BQU0sUUFBUTtBQUN0QyxnQkFBVSxJQUFJO0FBQUEsSUFDaEIsV0FBVyxVQUFVLFlBQVksTUFBTSxTQUFTO0FBQzlDLGdCQUFVLEtBQUs7QUFBQSxJQUNqQixPQUFPO0FBQ0wsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBQ0EsTUFBSSxhQUF1QjtBQUFBLElBQ3pCO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDQSxNQUFJLFdBQVcsU0FBUyxRQUFRLEdBQUc7QUFDakMsV0FBTztBQUFBLEVBQ1Q7QUFDQSxTQUFPLFlBQVksV0FBVztBQUNoQzsiLCJuYW1lcyI6W119